import os.path # module for file path manipulation
import sys # module for system specific parameters and functions
from Cryptodome.Hash import SHA256 # module for cryptographic hashing

# Validar a existência de argumentos em número e em tipo (termina o programa com erro se não for o caso)

if len(sys.argv) < 2: # if no file is given
    print("Usage: pyhton3 %s filename" % sys.argv[0]) # print usage
    sys.exit(1) # exit with error

fname = sys.argv[1] # get the file name from the arguments
if not os.path.exists(fname) or os.path.isdir(fname) or not os.path.isfile(fname): # if the file does not exist or is a directory
    print(fname + " is not a file", file=sys.stderr) # print error message
    sys.exit (2) # exit with error

# Calcular a síntese do ficheiro e apresentar o resultado

with open(fname, 'rb') as file:
    h = SHA256.new() # create a new hash object
    for line in file:
        h.update(line) # update the hash with the line
    print(h.hexdigest()) # print the hash

# Deu o mesmo resultado que o comando sha256sum