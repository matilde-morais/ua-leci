import sys # for sys.argv
from Cryptodome.Cipher import ARC4 # for ARC4 encryption
from Cryptodome.Hash import SHA256 # for hashing the key

def padKey(key):
    if len(key) < 5: # se achave for menor que 5 octetos, calcular hash SHA-256
        hashObj = SHA256.new()
        hashObj.update(key.encode("utf-8"))
        return hashObj.digest()
    elif len(key) > 256: # se a chave for maior que 256 octetos, truncar para 256
        return key[:256].encode("utf-8")
    else: 
        return key.encode("utf-8")
    
def encryptFile(filename, key):

    paddedKey = padKey(key) # obtém a chave padrão
    cipher = ARC4.new(paddedKey) # cria um objeto de cifra ARC4

    with open(filename, "rb") as file: # abre o arquivo em modo binário para leitura
        while True:
            data = file.read(4096) # lê 4096 octetos do arquivo
            if not data: # se não houver mais dados, termina o loop
                break
    
            cryptogram = cipher.encrypt(data) # criptografa os dados
            sys.stdout.buffer.write(cryptogram) # escreve os dados criptografados no stdout

def main():
    if len(sys.argv) != 3: # verifica se o número de argumentos está correto
        print("Uso: python3 cifraComRC4.py <ficheiro> <chave>")
        sys.exit(1) # termina o programa com erro

    filename = sys.argv[1]
    key = sys.argv[2]

    encryptFile(filename, key)

if __name__ == "__main__":
    main()  

# para redirigir o criptograma para um ficheiro, usar o comando:
# python3 cifraComRC4.py <ficheiro> <chave> > cryptogram

# stdin - 0
# stdout - 1
# stderr - 2
