import os
import random

from Cryptodome.Cipher import AES 

key = os.urandom(16) # random key with 16 bytes
cipher = AES.new(key, AES.MODE_ECB)

number = 23456
data = cipher.encrypt(bytes("%16d" % (number), "utf-8"))
print(data) # prints the encrypted number

value = int(str(cipher.decypt(data), "utf-8"))
print(value) # prints the decrypted number