import sys

from Cryptodome.Hash import SHA256
from Cryptodome.Cipher import AES

def padKey(key):
    if len(key) < 16: # Se a chave tiver menos de 16 octetos, calcular hash SHA-256
        hashObj = SHA256.new()
        hashObj.update(key.encode("utf-8"))
        return hashObj.digest()
    else: # Caso contrário, usar apenas os primeiros 16 octetos da chave fornecida
        return key.encode("utf-8")[:16]

def encryptFile(filename, key):
    paddedKey = padKey(key)
    cipher = AES.new(paddedKey, AES.MODE_ECB)

    with open(filename, 'rb') as file:
        while True:
            data = file.read(16)
            if not data:
                break

            if len(data) < 16:
                data += b' '*(16-len(data))
            
            criptograma = cipher.encrypt(data)
            sys.stdout.buffer.write(criptograma)

def main():
    if len(sys.argv) != 3:
        print("Uso: pyhton3 crifraComAES.py <ficheiro> <chave>")
        sys.exit(1)

    filename = sys.argv[1]
    key = sys.argv[2]

    encryptFile(filename, key)

if __name__ == "__main__":
    main()

# Para redirecionar o criptograma para um ficheiro, usar o comando:
# python3 cifraComAES.py <ficheiro> <chave> > criptograma

# stdin - 0
# stdout - 1
# stderr - 2