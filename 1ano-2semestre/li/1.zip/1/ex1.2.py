import os.path # module for file path manipulation
import sys # module for system specific parameters and functions
import hashlib # module for secure hashes and message digests

# Validar a existência de argumentos em número e em tipo (termina o programa com erro se não for o caso)

if len(sys.argv) < 2: # if no file is given
    print("Usage: pyhton3 %s filename" % sys.argv[0]) # print usage
    sys.exit(1) # exit with error

fname = sys.argv[1] # get the file name from the arguments
if not os.path.exists(fname) or os.path.isdir(fname) or not os.path.isfile(fname): # if the file does not exist or is a directory
    print(fname + " is not a file", file=sys.stderr) # print error message
    sys.exit (2) # exit with error

# Calcular o hash do ficheiro, usando blocos de 512 octetos de cada vez, e imprimir o resultado
    
def calculateHash(fname):
    h = hashlib.sha1() # create a new sha1 hash object
    with open(fname, 'rb') as file: # open the file in binary mode
        buffer = file.read(512) #read the first 512 bytes
        while len(buffer) > 0:
            h.update(buffer) # update the hash with the buffer
            buffer = file.read(512) # read the next 512 bytes
    print(h.hexdigest()) # print the hash of the file

calculateHash(fname) # call the function to calculate the hash of the file

# O resultado é o mesmo que obtido com o programa do ex1.1.py