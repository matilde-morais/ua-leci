import sys
import os

from Cryptodome.Hash import SHA256
from Cryptodome.Cipher import AES 

def padKey(key):
    if len(key) < 16:
        hashObj = SHA256.new()
        hashObj.update(key.encode("utf-8"))
        return hashObj.digest()
    else:
        return key.encode("utf-8")[:16]
    
def decryptFile(filename, key):
    paddedKey = padKey(key)
    cipher = AES.new(paddedKey, AES.MODE_ECB)

    with open(filename, 'rb') as file:
        filesize = os.path.getsize(filename)
        if filesize % 16 != 0:
            print(" Erro: O tamanho do ficheiro não é múltiplo de 16 bytes.")
            sys.exit(1)

        while True:
            data = file.read(16)
            if not data:
                break

            decifrado = cipher.decrypt(data)

            if filesize - file.tell() < 16:
                decifrado = decifrado.rstrip(b' ')

            sys.stdout.buffer.write(decifrado)

def main():
    if len(sys.argv) != 3:
        print("Uso: python3 decifraComAES.py <ficheiro> <chave>")
        sys.exit(1)

    filename = sys.argv[1]
    key = sys.argv[2]

    decryptFile(filename, key)

if __name__ == "__main__":
    main()