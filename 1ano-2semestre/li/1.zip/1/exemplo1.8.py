from Cryptodome.Cipher import AES

key = "1234567890abcdef" # Must provide a valid key (with 16, 24 or 32 bytes) key_size = 16 bytes
cipher = AES.new(key.encode("utf-8"), AES.MODE_ECB)
x = cipher.encrypt("texto para cifra".encode("utf-8"))
print(x) # prints the encrypted text
print(cipher.decrypt(x)) # prints the decrypted text