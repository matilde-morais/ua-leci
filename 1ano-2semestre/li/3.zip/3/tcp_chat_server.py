import socket
import select

def main():
    tcp_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_s.bind(("0.0.0.0", 1241)) # clientes multiplos na porta indicada
    tcp_s.listen(10) # aceita 10 clientes
    connections = []

    connections.append(tcp_s)
    print("Chat server started")

    while True:
        # lista de sockets que podem ser lidos pelo select
        read_sockets = select.select(connections, [], [])[0]

        for sock in read_sockets:
            if sock == tcp_s: # novo cliente?
                # adicionar socket de cliente novo á lista de sockets conhecidos
                client_s, addr = tcp_s.accept()
                connections.append(client_s)
                print("Client connected: %s" % str(addr))

            else:
                try: # verificar se há uma mensagem de um cliente e processá-la
                    data = sock.recv(4096) # mensagem válida de um cliente
                    if len(data) != 0:
                        print("From cliente: %s" % str(sock.getpeername()))
                        print("Got Data: " + data.decode("utf-8"))
                    else:
                        print("Cliente disconnected: %s" % str(sock.getpeername()))
                        connections.remove(sock)
                        sock.close()
                        # No need for break here
                        # break

                    # criar mensagem com identificaçao de quem a enviou
                    message = "<From client: " + str(sock.getpeername()) + ">"
                    message = message.encode("utf-8") + data.upper()

                    # eventualmente não mandar a mensagem para o próprio
                    for client in connections: 
                        if client != sock: 
                            client.send(message)

                except: #erro no socket do cliente
                    print("Client socket error: %s" % str(addr))
                    sock.close()
                    connections.remove(sock) # retirara esta socket da lista
                    continue

    for sock in connections: sock.close()

main()
