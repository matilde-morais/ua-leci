import socket
import select
import sys

def main():
    tcp_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        tcp_s.connect(("0.0.0.0", 1240))
        print("Connected to server")
    except ConnectionRefusedError:
        print("Failed to connect to server")
        return

    while True:
        rsocks = select.select([tcp_s, sys.stdin], [], [])[0] # lista de sockets que podem ser lidos pelo select

        for sock in rsocks:
            if sock == tcp_s:
                # informação recebida no socket
                b_data = tcp_s.recv(4096)
                if not b_data:
                    print("Disconnected from server")
                    return
                sys.stdout.write("%s\n" % b_data.decode("utf-8"))
                sys.stdout.flush()
            elif sock == sys.stdin:
                # informação recebida no stdin (teclado)
                str_data = sys.stdin.readline()
                tcp_s.send(str_data.encode("utf-8"))

    tcp_s.close()

main()
