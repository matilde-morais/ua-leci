package stand;

import java.util.Scanner;

public class MainStand {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        Stand stand = new Stand(100);
        int opcao = 0;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Adicionar um veiculo");
            System.out.println("2. Listar veiculos");
            System.out.println("3. Vender um veiculo");
            System.out.println("4. Calcular o lucro total");
            System.out.println("5. Sair");
            System.out.print("Opçao: ");
            opcao = sc.nextInt();
            switch (opcao) {
                case 1:
                    System.out.println("\n1. Adicionar um veiculo do tipo");
                    System.out.println("1. Passageiros");
                    System.out.println("2. Comercial");
                    System.out.println("3. Motorizada");
                    System.out.print("Tipo de produto: ");
                    int opcaoVeiculo = sc.nextInt();
                    sc.nextLine();
                    switch (opcaoVeiculo) {
                        case 1:
                            System.out.println("Marca: ");
                            marca = sc.nextString();
                            System.out.println("Modelo: ");
                            modelo = sc.nextString();
                            System.out.println("Preço: ");
                            precoBase = sc.nextDouble();

                            break;
                        case 2:
                            // Adicionar Veiculo Comercial
                            break;
                        case 3:
                            // Adicionar Motorizada;
                            break;
                    }
                    break;
                case 2:
                    // Listar Veiculos
                    break;
                case 3:
                    
                    break;
                case 4:
                    
                    break;
                case 5:
                    System.out.println("5. Sair");
                    sc.close();
                    break;
            }
        } while (opcao != 5);
    }
}
