package stand;

public class Motorizada extends Veiculo {

    // ATRIBUTOS

    private int numeroRodas;
    private double velocidadeMaxima;

    // CONSTRUTOR

    public Motorizada(String marca, String modelo, double precoBase, int numeroRodas, double velocidadeMaxima, String unidadeVelocidade) {
        super(marca, modelo, precoBase);

        // VALIDAR VALORES

        if (numeroRodas > 0 && velocidadeMaxima > 0) {
            this.numeroRodas = numeroRodas;
            this.velocidadeMaxima = velocidadeMaxima;
        } else {
            throw new IllegalArgumentException("Valores Inválidos!");
        }
        
    }

    // SETTERS

    public void setNumeroRodas(int numeroRodas) {
        if (numeroRodas > 0) {
            this.numeroRodas = numeroRodas;
        } else {
            throw new IllegalArgumentException("Número de Rodas Inválido!");
        }
    }

    public void setVelocidadeMaxima(double velocidadeMaxima) {
        if (velocidadeMaxima > 0) {
            this.velocidadeMaxima = velocidadeMaxima;
        } else {
            throw new IllegalArgumentException("Velocidade Máxima Inválida!");
        }
    }

    // GETTERS

    public int getNumeroRodas() {
        return numeroRodas;
    }

    public double getVelocidadeMaxima() {
        return velocidadeMaxima;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Veiculo Motorizado [marca=" + getMarca() + ", modelo=" + getModelo() + ", precoBase=" + getPrecoBase() +
                ", numeroRodas=" + numeroRodas + ", velocidadeMaxima=" + velocidadeMaxima + " km/h]";
    }
}
