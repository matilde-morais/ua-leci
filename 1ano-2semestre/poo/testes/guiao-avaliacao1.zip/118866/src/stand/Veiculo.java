package stand;

import java.util.Objects;

public class Veiculo {

    // ATRIBUTOS

    private static int codigoId = 1000;

    private String marca;
    private String modelo;
    private double precoBase;
    private int codigo;

    // CONSTRUTOR

    public Veiculo(String marca, String modelo, double precoBase) {

        // VALIDAR OS VALORES

        if (marca != null && modelo != null && precoBase > 0) {
            this.marca = marca;
            this.modelo = modelo;
            this.precoBase = precoBase;
            this.codigo = codigoId++;
        } else {
            throw new IllegalArgumentException("Valores inválidos!");
        }

    }

    //SETTERS

    public void setMarca(String marca) {
        if (marca != null) {
            this.marca = marca;
        } else {
            throw new IllegalArgumentException("Marca inválida1");
        }
    }

    public void setModelo(String modelo) {
        if (modelo != null) {
            this.modelo = modelo;
        } else {
            throw new IllegalArgumentException("Modelo inválido!");
        }
    }

    public void setPrecoBase(double precoBase) {
        if (precoBase > 0) {
            this.precoBase = precoBase;
        } else {
            throw new IllegalArgumentException("Preço inválido!");
        }
    }

    //GETTERS

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecoBase() {
        return precoBase;
    }

    public int getCodigo() {
        return codigo;
    }

    //MÉTODOS

    @Override 
    public String toString() { 
        return "Veiculo [codigo=" + codigo + ", marca=" + marca + ", modelo=" + modelo + ", precoBase=" + precoBase + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }
        Veiculo v = (Veiculo) obj;
        return this.marca.equals(v.getMarca()) && this.modelo.equals(v.getModelo()) && this.precoBase == v.getPrecoBase();
    }

    @Override
    public int hashCode() {
        return Objects.hash(marca, modelo, precoBase);
    }

}