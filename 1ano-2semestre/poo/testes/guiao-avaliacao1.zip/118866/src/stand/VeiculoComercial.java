package stand;

public class VeiculoComercial extends Veiculo {

    // ATRIBUTOS

    private String formato;
    private double capacidadeCarga;
    private String unidadeCarga;

    // CONSTRUTOR

    public VeiculoComercial(String marca, String modelo, double precoBase, String formato, double capacidadeCarga, String unidadeCarga) {
        super(marca, modelo, precoBase);

        // VALIDAR OS VALORES

        if (formato != null && capacidadeCarga > 0 && unidadeCarga != null) {
            this.setFormato(formato);
            this.setCapacidadeCarga(capacidadeCarga);
            this.setUnidadeCarga(unidadeCarga);
        } else {
            throw new IllegalArgumentException("Valores Inválidos!");
        }
        
    }

    // SETTERS

    public void setFormato(String formato) {
        if (formato != null) {
            this.formato = formato;
        } else {
            throw new IllegalArgumentException("Formato Inválido!");
        }
    }

    public void setCapacidadeCarga(double capacidadeCarga) {
        if (capacidadeCarga > 0) {
            this.capacidadeCarga = capacidadeCarga;
        } else {
            throw new IllegalArgumentException("Capacidade de Carga Inválida!");
        }
    }

    public void setUnidadeCarga(String unidadeCarga) {
        if (unidadeCarga != null) {
            this.unidadeCarga = unidadeCarga;
        } else {
            throw new IllegalArgumentException("Unidade de Carga Inválida!");
        }
    }

    // GETTERS

    public String getFormato() {
        return formato;
    }

    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    public String getUnidadeCarga() {
        return unidadeCarga;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Veiculo Comercial [marca=" + getMarca() + ", modelo=" + getModelo() + ", precoBase=" + getPrecoBase() +
                ", formato=" + formato + ", capacidadeCarga=" + capacidadeCarga + " " + unidadeCarga + "]";
    }
}
