package stand;

public class VeiculoPassageiros extends Veiculo {

    // ATRIBUTOS

    private int capacidadePassageiros;
    private String tipoMotorizacao;
    private double potenciaCV;
    private double potenciaKW;

    // CONSTRUTOR

    public VeiculoPassageiros(String marca, String modelo, double precoBase, int capacidadePassageiros, String tipoMotorizacao, double potenciaCV) {
        super(marca, modelo, precoBase);

        // VALIDAR OS VALORES

        if (capacidadePassageiros > 0 && tipoMotorizacao != null && potenciaCV > 0) {
            this.capacidadePassageiros = capacidadePassageiros;
            this.tipoMotorizacao = tipoMotorizacao;
            this.setPotenciaCV(potenciaCV);
        } else {
            throw new IllegalArgumentException("Valores Inválidos!");
        }
        
    }

    // SETTERS

    public void setCapacidadePassageiros(int capacidadePassageiros) {
        if (capacidadePassageiros > 0) {
            this.capacidadePassageiros = capacidadePassageiros;
        } else {
            throw new IllegalArgumentException("Capacidade de Passageiros Inválida!");
        }
    }

    public void setTipoMotorizacao(String tipoMotorizacao) {
        if (tipoMotorizacao != null) {
            this.tipoMotorizacao = tipoMotorizacao;
        } else {
            throw new IllegalArgumentException("Tipo de Motorização Inválido!");
        }
    }

    public void setPotenciaCV(double potenciaCV) {
        if (potenciaCV > 0) {
            this.potenciaCV = potenciaCV;
            this.potenciaKW = potenciaCV * 0.7355;
        } else {
            throw new IllegalArgumentException("Potência em CV Inválida!");
        }
    }

    // GETTERS

    public int getCapacidadePassageiros() {
        return capacidadePassageiros;
    }

    public String getTipoMotorizacao() {
        return tipoMotorizacao;
    }

    public double getPotenciaCV() {
        return potenciaCV;
    }

    public double getPotenciaKW() {
        return potenciaKW;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Veiculo de Passageiros [marca=" + getMarca() + ", modelo=" + getModelo() + ", precoBase=" + getPrecoBase() +
                ", capacidadePassageiros=" + capacidadePassageiros + ", tipoMotorizacao=" + tipoMotorizacao + ", potenciaCV=" + potenciaCV +
                " CV, potenciaKW=" + potenciaKW + " kW]";
    }

}