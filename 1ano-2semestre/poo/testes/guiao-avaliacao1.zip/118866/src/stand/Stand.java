package stand;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Stand {

    // ATRIBUTOS

    private Map<Integer, Veiculo> veiculos; // codigo, veiculo
    private double lucroTotal;

    // Stand()

    public Stand() {
        veiculos = new HashMap<>();
        lucroTotal = 0.0;
    }

    // MÉTODOS

    public void adicionarVeiculo(Veiculo veiculo) {
        if (veiculo != null && veiculo.getPrecoBase() > 0) {
            veiculos.put(veiculo.getCodigo(), veiculo);
        } else {
            throw new IllegalArgumentException("Veículo Inválido ou Preço Base Inválido.");
        }
    }

    public List<Veiculo> listarVeiculosDisponiveis() {
        return new ArrayList<>(veiculos.values());
    }

    public void vender(int codigoVeiculo, double precoVenda) {
        if (precoVenda <= 0) {
            throw new IllegalArgumentException("Preço de Venda Inválido.");
        }

        if (veiculos.containsKey(codigoVeiculo)) {
            Veiculo veiculo = veiculos.get(codigoVeiculo);
            double lucro = precoVenda - veiculo.getPrecoBase();
            lucroTotal += lucro;
            veiculos.remove(codigoVeiculo);
            System.out.println("Veículo vendido com sucesso! Lucro: " + lucro + "€");
        } else {
            throw new IllegalArgumentException("Veículo Não Encontrado!");
        }
    }

    public double lucro() {
        return lucroTotal;
    }

}
