public class StandardShippingCostCalculator implements IShippingCostCalculator {

    @Override
    public double calculateShippingCost(Parcel p) {
        
        double weight = p.getWeight();

        if (weight < 5) {
            return weight * 1.0;
        } else if (weight <= 10) {
            return weight * 0.75;
        } else {
            return weight * 0.5;
        }
    }
}
