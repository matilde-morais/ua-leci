import java.io.IOException;
import java.nio.file.*;
import java.util.*;

public class ParcelManager {

    // ATRIBUTOS

    private List<Parcel> parcels;
    private IShippingCostCalculator shippingCostCalculator;

    // CONSTRUTOR

    public ParcelManager(IShippingCostCalculator shippingCostCalculator) {

        this.parcels = new ArrayList<>();
        this.shippingCostCalculator = shippingCostCalculator;

    }

    // MÉTODOS

    public void addParcel(Parcel p) {
        if (p != null) {
            parcels.add(p);
        } else {
            throw new IllegalArgumentException("Encomenda Inválida: a encomenda não pode ser nula!");
        }
    }

    public void removeParcel(int id) {
        if (id > 0) {
            Iterator<Parcel> iterator = parcels.iterator();
            while (iterator.hasNext()) {
                Parcel p = iterator.next();
                if (p.getId() == id) {
                    iterator.remove();
                    return;
                }
            }
            throw new IllegalArgumentException("Encomenda Não Encontrada: ID " + id + " não existe!");
        } else {
            throw new IllegalArgumentException("ID Inválido: deve ser maior que zero!");
        }
    }

    public Parcel getParcel(int id) {
        if (id > 0) {
            for (Parcel p : parcels) {
                if (p.getId() == id) {
                    return p;
                }
            }
            throw new IllegalArgumentException("Encomenda Não Encontrada: ID " + id + " não existe!");
        } else {
            throw new IllegalArgumentException("ID Inválido: deve ser maior que zero!");
        }
    }

    public List<Parcel> printAllParcels() {
        return new ArrayList<>(parcels);
    }

    public double calculateShippingCost(int id) {
        if (id > 0) {
            for (Parcel p : parcels) {
                if (p.getId() == id) {
                    return shippingCostCalculator.calculateShippingCost(p);
                }
            }
            throw new IllegalArgumentException("Encomenda Não Encontrada: ID " + id + " não existe!");
        } else {
            throw new IllegalArgumentException("ID Inválido: deve ser maior que zero!");
        }
    }

    public List<String> readFile(String fich) { // tenho de terminar este método
        try {
            return Files.readAllLines(Paths.get(fich));
        } catch (IOException e) {
            throw new RuntimeException("Erro Ao Ler O Arquivo: " + fich, e);
        }
    }

    public void writeFile(String fich) {
        try {
            List<String> lines = new ArrayList<>();
            for (Parcel p : parcels) {
                String line = String.format("%s;%s;%f;%f", p.getRemetente(), p.getDestination(), p.getWeight(), calculateShippingCost(p.getId()));
                lines.add(line);
            }
            Files.write(Paths.get(fich), lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            throw new RuntimeException("Erro Ao Escrever O Arquivo: " + fich, e);
        }
    }
    
}
