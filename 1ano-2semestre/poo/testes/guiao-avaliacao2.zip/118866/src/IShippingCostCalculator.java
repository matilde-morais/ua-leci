public interface IShippingCostCalculator {
    public double calculateShippingCost(Parcel p);
}
