public class Parcel {

    // ATRIBUTOS

    private static int nextId = 1;
    private int id;
    private double weight;
    private String destination;
    private String remetente;

    // CONSTRUTOR

    public Parcel(double weight, String destination, String remetente) {

        // VALIDAÇÃO

        if (weight > 0 && destination != null && remetente != null) {
            this.id = nextId++;
            this.weight = weight;
            this.destination = destination;
            this.remetente = remetente;
        } else {
            throw new IllegalArgumentException("Encomenda inválida!");
        }

    }

    // SETTERS

    public void setId(int id) {
        if (id > 0) {
            this.id = id;
        } else {
            throw new IllegalArgumentException("ID inválido!");
        }
    }

    public void setWeight(double weight) {
        if (weight > 0) {
            this.weight = weight;
        } else {
            throw new IllegalArgumentException("Peso inválido!");
        }
    }

    public void setDestination(String destination) {
        if (destination != null) {
            this.destination = destination;
        } else {
            throw new IllegalArgumentException("Destino inválido!");
        }
    }

    public void setRemetente(String remetente) {
        if (remetente != null) {
            this.remetente = remetente;
        } else {
            throw new IllegalArgumentException("Remetente inválido!");
        }
    }

    // GETTERS

    public int getId() {
        return id;
    }

    public double getWeight() {
        return weight;
    }

    public String getDestination() {
        return destination;
    }

    public String getRemetente() {
        return remetente;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "ID: " + id + "\nPeso: " + weight + "\nDestino: " + destination + "\nRemetente: " + remetente;
    }
    
}