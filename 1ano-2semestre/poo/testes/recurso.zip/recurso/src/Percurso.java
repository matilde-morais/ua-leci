import java.util.ArrayList;
import java.util.List;

public class Percurso {
    
    public static void main(String[] args) {

        // ATRIBUTOS

        Float PrecoPessoa;
        String Transporte;
        ArrayList<Local> Locais = new ArrayList<Local>();

        // CONSTRUTOR

        public Percurso(Float PrecoPessoa, String Transporte) {

            // VALIDAÇÃO

            if (PrecoPessoa == null || PrecoPessoa <= 0 || Transporte == null || Transporte.isEmpty() || (Transporte != "Autocarro" || Transporte != "TodoTerreno" || Transporte != "Bicicleta")) {
                throw new IllegalArgumentException("Dados Inválidos!");
            } else {
                this.PrecoPessoa = PrecoPessoa;
                this.Transporte = Transporte;
            }
        }

        // SETTTERS

        public void setPrecoPessoa(Float PrecoPessoa) {
            if (PrecoPessoa == null || PrecoPessoa <= 0) {
                throw new IllegalArgumentException("Preço por Pessoa Inválido!");
            } else {
                this.PrecoPessoa = PrecoPessoa;
            }
        }

        public void setTransporte(String Transporte) {
            if (Transporte == null || Transporte.isEmpty() || (Transporte != "Autocarro" || Transporte != "TodoTerreno" || Transporte != "Bicicleta")) {
                throw new IllegalArgumentException("Tipo de Transporte Inválido!");
            } else {
                this.Transporte = Transporte;
            }
        }

        public void add(Local local) {
            Locais.add(Local());
        }

        // GETTERS

        public Float getPrecoPessoa() {
            return PrecoPessoa;
        }

        public String getTransporte() {
            return Transporte;
        }

        public ArrayList<Local> getLocais() {
            return Locais;
        }

        // MÉTODOS

        @Override
        public String toString() {
            return 
        }

    }
}
