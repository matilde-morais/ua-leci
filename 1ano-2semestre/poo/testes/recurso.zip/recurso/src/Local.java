public class Local {
    
    public static void main(String[] args) {

        // ATRIBUTOS

        String nome;
        String TipoLocal;

        // CONSTRUTOR

        public Local(String nome, String TipoLocal) {

            // VALIDAÇÃO

            if ((nome == null || nome.isEmpty()) && (TipoLocal == null || TipoLocal.isEmpty()) || (TipoLocal != "Restaurante" || TipoLocal != "SitioCultural")) {
                throw new IllegalArgumentException("Dados Inválidos!");
            } else {
                this.nome = nome;
                this.TipoLocal = TipoLocal;
            }
        }

        // SETTTERS

        public void setNome(String nome) {
            if (nome == null || nome.isEmpty()) {
                throw new IllegalArgumentException("Nome Inválido!");
            } else {
                this.nome = nome;
            }
        }

        public void setTipoLocal(String TipoLocal) {
            if (TipoLocal == null || TipoLocal.isEmpty() || (TipoLocal != "Restaurante" || TipoLocal != "SitioCultural")) {
                throw new IllegalArgumentException("Tipo de Local Inválido!");
            } else {
                this.TipoLocal = TipoLocal;
            }
        }

        // GETTERS

        public String getNome() {
            return nome;
        }

        public String getTipoLocal() {
            return TipoLocal;
        }

        // MÉTODOS

        @Override
        public String toString() {
            return getTipoLocal() + " " + getNome();
        }
    
    }
}
