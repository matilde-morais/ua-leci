public class Restaurante {
    
    public static void main(String[] args) {

        // ATRIBUTOS

        String TipoComida;

        // CONSTRUTOR

        public Restaurante(String nome, String TipoLocal, String TipoComida) {

            // VALIDAÇÃO

            if (TipoComida == null || TipoComida.isEmpty() || (TipoComida != "Mediterrênica" || TipoComida != "Oriental" || TipoComida != "Vegetariana")) {
                throw new IllegalArgumentException("Tipo de COMIDA Inválido!");
            } else {
                super.nome = nome;
                super.TipoLocal = TipoLocal;
                this.TipoComida = TipoComida;
            }
        }

        // SETTTERS

        public void setTipoComida(String nome) {
            if (TipoComida == null || TipoComida.isEmpty() || (TipoComida != "Mediterrênica" || TipoComida != "Oriental" || TipoComida != "Vegetariana")) {
                throw new IllegalArgumentException("Tipo de Comida Inválido!");
            } else {
                this.TipoComida = TipoComida;
            }
        }

        // GETTERS

        public String getTipoComida() {
            return "Comida " + TipoComida;
        }

        // MÉTODOS

        @Override
        public String toString() {
            return super.toString() + ", " + getTipoComida();
        }

    }

}
