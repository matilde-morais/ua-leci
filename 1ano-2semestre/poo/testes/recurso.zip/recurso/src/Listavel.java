import java.util.Collection;

public interface Listavel {
	Collection<String> percursos();
}
