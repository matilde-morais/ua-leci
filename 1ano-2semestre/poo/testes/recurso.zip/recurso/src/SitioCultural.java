public class SitioCultural {

    public static void main(String[] args) {

        // ATRIBUTOS

        String TipoCultural;
        String GamaPrecos;

        // CONSTRUTOR

        public SitioCultural(String nome, String TipoLocal, String TipoCultural, String GamaPrecos) {

            // VALIDAÇÃO

            if ((TipoCultural == null || TipoCultural.isEmpty() || (TipoCultural != "MuseuArte" || TipoCultural != "MuseuCiencia" || TipoCultural != "Historico" || TipoCultural != "Religioso")) && (GamaPrecos == null || GamaPrecos.isEmpty() || (GamaPrecos != "Gratuito" || GamaPrecos != "Barato" || GamaPrecos != "Médio"))) {
                throw new IllegalArgumentException("Dados Inválidos!");
            } else {
                super.nome = nome;
                super.TipoLocal = TipoLocal;
                this.TipoCultural = TipoCultural;
                this.GamaPrecos = GamaPrecos;
            }
        }

        // SETTTERS

        public void setTipoCultural(String TipoCultural) {
            if (TipoCultural == null || TipoCultural.isEmpty() || (TipoCultural != "MuseuArte" || TipoCultural != "MuseuCiencia" || TipoCultural != "Historico" || TipoCultural != "Religioso")) {
                throw new IllegalArgumentException("Tipo Cultural Inválido!");
            } else {
                this.TipoCultural = TipoCultural;
            }
        }

        public void setGamaPrecos(String GamaPrecos) {
            if (GamaPrecos == null || GamaPrecos.isEmpty() || (GamaPrecos != "Gratuito" || GamaPrecos != "Barato" || GamaPrecos != "Médio")) {
                throw new IllegalArgumentException("Gama de Preços Inválida!");
            } else {
                this.GamaPrecos = GamaPrecos;
            }
        }

        // GETTERS

        public String getTipoCultural() {
            return TipoCultural;
        }

        public String getGamaPrecos() {
            return GamaPrecos;
        }

        // MÉTODOS

        @Override
        public String toString() {
            return super.toString() + ", " + getTipoCultural() + ", " + getGamaPrecos();
        }

    }
    
}
