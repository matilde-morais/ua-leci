package aula03;

import java.util.Scanner;

public class Ex6 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite uma palavra, frase ou parágrafo:");
        String texto = scanner.nextLine();

        String textoMinusculo = texto.toLowerCase();
        System.out.println("Frase em minúsculas: " + textoMinusculo);

        char ultimoCaractere = texto.charAt(texto.length() - 1);
        System.out.println("Último caractere da frase: " + ultimoCaractere);

        String tresPrimeirosCaracteres = texto.substring(0, Math.min(texto.length(), 3));
        System.out.println("Os 3 primeiros caracteres da frase: " + tresPrimeirosCaracteres);

        int comprimento = texto.length();
        System.out.println("Comprimento da frase: " + comprimento);

        String textoSubstituido = texto.replace('a', 'x');
        System.out.println("Frase com substituição de 'a' por 'x': " + textoSubstituido);

        boolean contemExemplo = texto.contains("exemplo");
        System.out.println("A frase contém a palavra 'exemplo': " + contemExemplo);

        scanner.close();
    }
}