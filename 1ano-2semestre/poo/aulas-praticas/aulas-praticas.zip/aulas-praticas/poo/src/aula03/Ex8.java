package aula03;

import java.util.Scanner;

public class Ex8 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduza uma frase:");
        String frase = scanner.nextLine();

        String acronimo = gerarAcronimo(frase);
        System.out.println("Acrónimo: " + acronimo);

        scanner.close();
    }

    public static String gerarAcronimo(String frase) {
        StringBuilder acronimo = new StringBuilder();

        String[] palavras = frase.split(" ");

        for (String palavra : palavras) {
            if (palavra.length() >= 3) {
                acronimo.append(Character.toUpperCase(palavra.charAt(0)));
            }
        }

        return acronimo.toString();
    }
}