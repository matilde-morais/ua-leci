package aula03;

import java.util.Scanner;

public class Ex7 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite uma frase:");
        String frase = scanner.nextLine();

        int numCaracteresNumericos = countDigits(frase);
        System.out.println("Número de caracteres numéricos na frase: " + numCaracteresNumericos);

        int numEspacos = countSpaces(frase);
        System.out.println("Número de espaços na frase: " + numEspacos);

        boolean soContemMinusculas = isLowercase(frase);
        System.out.println("A frase só contém minúsculas: " + soContemMinusculas);

        String fraseSemEspacosMultiplos = removeExtraSpaces(frase);
        System.out.println("Frase com espaços múltiplos removidos: " + fraseSemEspacosMultiplos);

        boolean ehPalindromo = isPalindrome(frase);
        System.out.println("A frase é um palíndromo: " + ehPalindromo);

        scanner.close();
    }

    public static int countDigits(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (Character.isDigit(s.charAt(i))) {
                count++;
            }
        }
        return count;
    }

    public static int countSpaces(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ') {
                count++;
            }
        }
        return count;
    }

    public static boolean isLowercase(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isLowerCase(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static String removeExtraSpaces(String s) {
        return s.replaceAll("\\s+", " ");
    }

    public static boolean isPalindrome(String s) {
        String reverse = new StringBuilder(s).reverse().toString();
        return s.equalsIgnoreCase(reverse);
    }
}