package aula03;

import java.util.Scanner;

public class Ex1 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int numero;

        do { // leitura de número positivo
            System.out.println("Insira um número inteiro positivo: ");
            numero = scanner.nextInt();
        } while (numero < 0);

        // cálculo de soma dos primos
        int somaPrimos = 0;
        for (int i = 2; i <= numero; i++) {
            if (serPrimo(i)) {
                somaPrimos += i;
            }
        }

        System.out.println("Soma dos primos até " + numero + ": " + somaPrimos);

        scanner.close();

    }    
        // verificar se é primo
    private static boolean serPrimo(int numero) {

        if (numero <= 1) {
            return false;
        }
        for(int i=2; i*i <= numero; i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;

    }

}
