package aula03;

import java.util.Scanner;

    public class Ex4 {
        
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
    
            System.out.println("Quantos alunos na turma?");
            int numAlunos = scanner.nextInt();
    
            double[][] notas = new double[numAlunos][2];
    
            for (int i = 0; i < numAlunos; i++) {
                System.out.println("Insira as notas para o aluno " + (i + 1) + ":");
                System.out.print("Nota teórica: ");
                notas[i][0] = scanner.nextDouble();
                System.out.print("Nota prática: ");
                notas[i][1] = scanner.nextDouble();
            }
    
            System.out.println("NotaT\tNotaP\tPauta");
            for (int i = 0; i < numAlunos; i++) {
                double notaT = notas[i][0];
                double notaP = notas[i][1];
                double notaFinal = calcularNotaFinal(notaT, notaP);
                System.out.println(notaT + "\t" + notaP + "\t" + notaFinal);
            }
    
            scanner.close();
        }
    
        public static double calcularNotaFinal(double notaT, double notaP) {
            if (notaT < 7.0 || notaP < 7.0) {
                return 66;
            } else {
                return Math.round(0.4 * notaT + 0.6 * notaP);
            }
        }
    }