package aula03;

import java.util.Scanner;

public class Ex2 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int investimento;
        do { // leitura de um numero positivo e multiplo de 1000
            System.out.println("Insira o valor de investimento, positivo e múltiplo de 1000: ");
            investimento = scanner.nextInt();
        } while (investimento <= 0 || investimento % 1000 != 0);

        double juroMensal;
        do { // leitura da percentagem de juros
            System.out.println("Insira a percentagem de juros mensal, entre 0 e 5: ");
            juroMensal = scanner.nextDouble();
        } while (juroMensal <= 0 || juroMensal >= 5);
        
        int valorMensal = investimento;

        for (int i = 1; i <= 12; i++) {
            double esteMes = valorMensal * (juroMensal/100);
            valorMensal += esteMes;
            System.out.println("Mês " + i + ":" + valorMensal);
        }

        scanner.close();

    }

}
