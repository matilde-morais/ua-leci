package aula03;

import java.util.Scanner;

public class Ex3 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String resposta;

        do {
            // numero aleatorio entre 1 e 100
            int numAleatorio = (int) (Math.random() * 100) + 1;
            // quantas tentativas
            int tentativas = 0;
            // quer continuar?
            boolean continuar = true;

            while (continuar) {
                tentativas++;

                System.out.println("Introduz a tua tentativa: ");
                int guess = scanner.nextInt();

                if (guess == numAleatorio) {
                    System.out.println("Acertaste! Parabéns!");
                    continuar = false;
                } else if (guess > numAleatorio) {
                    System.out.println("Muito alto!");
                } else {
                    System.out.println("Muito baixo!");
                }
                System.out.println("Tentativas: " + tentativas);
            }

            System.out.println("Deseja continuar? (S ou N/ Sim ou Não) ");
            resposta = scanner.next();
        } while (resposta.equalsIgnoreCase("S") || resposta.equalsIgnoreCase("Sim"));

        System.out.println("Obrigada por jogar!");

        scanner.close();

    }

}