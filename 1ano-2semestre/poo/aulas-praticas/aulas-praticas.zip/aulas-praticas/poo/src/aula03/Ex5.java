package aula03;

import java.util.Scanner;

public class Ex5 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira a data no formato mm/yyyy:");
        String data = scanner.nextLine();

        while (!validarData(data)) {
            System.out.println("Data inválida. Insira novamente no formato mm/yyyy:");
            data = scanner.nextLine();
        }

        System.out.println("Insira o dia da semana em que começa o mês (1 a 7):");
        int diaSemanaInicio = scanner.nextInt();

        imprimirCalendario(data, diaSemanaInicio);

        scanner.close();
    }

    public static boolean validarData(String data) {
        String[] partes = data.split("/");
        if (partes.length != 2) {
            return false;
        }
        int mes = Integer.parseInt(partes[0]);
        int ano = Integer.parseInt(partes[1]);
        return mes >= 1 && mes <= 12 && ano >= 0;
    }

    public static void imprimirCalendario(String data, int diaSemanaInicio) {
        String[] partes = data.split("/");
        int mes = Integer.parseInt(partes[0]);
        int ano = Integer.parseInt(partes[1]);

        int diasNoMes = calcularDiasNoMes(mes, ano);

        System.out.println(getNomeMes(mes) + " " + ano);
        System.out.println("Su Mo Tu We Th Fr Sa");

        for (int i = 1; i < diaSemanaInicio; i++) {
            System.out.print("   ");
        }

        for (int dia = 1; dia <= diasNoMes; dia++) {
            System.out.printf("%2d ", dia);
            if ((dia + diaSemanaInicio - 1) % 7 == 0 || dia == diasNoMes) {
                System.out.println();
            }
        }
    }

    public static int calcularDiasNoMes(int mes, int ano) {
        if (mes == 2) {
            return ano % 4 == 0 && (ano % 100 != 0 || ano % 400 == 0) ? 29 : 28;
        } else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
            return 30;
        } else {
            return 31;
        }
    }

    public static String getNomeMes(int mes) {
        switch (mes) {
            case 1:
                return "January";
            case 2:
                return "February";
            case 3:
                return "March";
            case 4:
                return "April";
            case 5:
                return "May";
            case 6:
                return "June";
            case 7:
                return "July";
            case 8:
                return "August";
            case 9:
                return "September";
            case 10:
                return "October";
            case 11:
                return "November";
            case 12:
                return "December";
            default:
                return "";
        }
    }
}