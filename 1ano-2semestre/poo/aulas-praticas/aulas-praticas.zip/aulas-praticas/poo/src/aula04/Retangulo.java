package aula04;

public class Retangulo {
    
    private double comprimento;
    private double altura;

    public getMedidas() {
        return new double[] {comprimento, altura}; // devolve um array com o comprimento e a altura
    }

    public setMedidas(double comprimento, double altura) {
        if (comprimento > 0 && altura > 0) { // comprimento e altura têm de ser positivos
            this.comprimento = comprimento;
            this.altura = altura;
        } else {
            throw new IllegalArgumentException ("O comprimento e a altura têm de ser valores positivos."); // throw new IllegalArgumentException é uma forma de lançar uma exceção
        }
    }

    @Override // anotação que indica que o método que se segue sobrepõe o método toString da classe Object
    public String toString() {
        return "Retângulo com comprimento " + comprimento + " e altura " + altura;
    }

    @Override // anotação que indica que o método que se segue sobrepõe o método equals da classe Object
    public boolean equals(Object obj) {
        // ???
    }

    public double area() {
        return comprimento * altura;
    }

    public double perimetro() {
        return 2*comprimento + 2*altura;
    }
}