package aula04;

public class Circulo {
    
    private double raio;

    public double getRaio() {
        return raio;
    }

    public setRaio(double raio) {
        if (raio <= 0) {
            throw new IllegalArgumentException("O raio deve ser um valor positivo.");
        }
        this.raio = raio;
    }

    @Override
    public String toString() {
        return "Círculo com raio " + raio;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Circulo outroCirculo = (Circulo) obj;
        return Double.compare(outroCirculo.raio, raio) == 0;
    }

    public double area() {
        
    }

    public double perimetro() {
        
    }
}

