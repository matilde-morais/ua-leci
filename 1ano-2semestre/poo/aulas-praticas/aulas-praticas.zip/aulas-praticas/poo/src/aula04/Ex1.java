package aula04;

import java.util.Scanner;

public class Ex1 {    

    public static void main(String[] args) {

        //testar todas as classes e metodos

    }

}
