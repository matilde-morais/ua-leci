package aula04;

public class Triangulo {
    
    private double lado1;
    private double lado2;
    private double lado3;

    public getLados() {
        return new double[] {lado1, lado2, lado3}
    }

    public setLados(double lado1, double lado2, double lado3) {
        // lados têm de ser positivos
        // tem de satisfazer a desigualdade triangular
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }

    @Override
    public String toString() {

    }

    @Override
    public boolean equals(Object obj) {

    }

    public double area() {
        // formula de Heron
    }

    public double perimetro() {

    }
}
