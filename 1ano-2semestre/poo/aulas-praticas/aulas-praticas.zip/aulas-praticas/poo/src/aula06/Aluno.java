package aula06;

import aula05.DateYMD;

public class Aluno extends Pessoa {

    private static int nMec = 100;

    private int nMecanografico;A
    private DateYMD dataInscr;

    // CONSTRUTOR COM DATA DE INSCRICAO

    public Aluno(String nome, int cc, DateYMD dataNasc, DateYMD dataIncr) {

        super(nome, cc, dataNasc);
        this.nMecanografico = nMec++;
        if (dataInscr != null) {
            if (dataInscr.valid(dataInscr.getDay(), dataInscr.getMonth(), dataIncr.getYear())) {
                this.dataInscr = dataInscr;
            } else {
                throw new IllegalArgumentException("Data Inválida!");
            }
        } else {
            throw new IllegalArgumentException("Data Inválida!");
        }

    }

    // CONSTRUTOR COM DATA ATUAL

    public Aluno(String nome, int cc, DateYMD dataNasc) {

        
    }

}