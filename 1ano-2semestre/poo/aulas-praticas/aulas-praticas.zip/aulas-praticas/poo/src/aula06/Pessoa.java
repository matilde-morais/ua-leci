package aula06;

import aula05.DateYMD;

public class Pessoa {

    private String nome;
    private int cc;
    private DateYMD dataNasc;

    public Pessoa(String nome, int cc, DateYMD dataNasc) {

        // VALIDAR OS VALORES

        if (nome != null || cc >= 0 || dataNasc != null) {

            if (dataNasc.valid(dataNasc.getDay(), dataNasc.getMonth(), dataNasc.getYear())) {

                this.nome = nome;
                this.cc = cc;
                this.dataNasc = dataNasc;

            } else {
                throw new IllegalArgumentException("Data Inválida!");
            }
        } else {
            throw new IllegalArgumentException("Valores Inválidos!");
        }
        
    }

    // SETTERS

    public void setNome(String nome) {

        if (nome != null) {
            this.nome = nome;
        } else {
            throw new IllegalAtgumentException("Nome Inválido!");
        }
    }

    public void setCC(int cc) {

        if (cc >= 0) {
            this.cc = cc;
        } else {
            throw new IllegalAtgumentException("Nº de Cartão de Cidadão Inválido!");
        }

    }

    public void setData(DateYMD dataNasc) {

        if (dataNasc != null) {
            if (dataNasc.valid(dataNasc.getDay(), dataNasc.getMonth(), dataNasc.getYear())) {
                this.dataNasc = dataNasc;
            } else {
                throw new IllegalAtgumentException("Data Inválida!");
            }
        } else {
            throw new IllegalAtgumentException("Data Inválida!");
        }

    }

    // GETTERS

    public String getNome() {

        return nome;

    }

    public int getCC() {

        return cc;

    }

    public DateYMD getData() {

        return dataNasc;

    }

}