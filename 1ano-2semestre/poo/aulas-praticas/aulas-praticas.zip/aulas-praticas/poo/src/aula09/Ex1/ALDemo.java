package aula09.Ex1;



import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class ALDemo {
    public static void main(String[] args) {

        ArrayList<Integer> c1 = new ArrayList<>();
        for (int i = 10; i <= 100; i+=10) 
            c1.add(i);
        System.out.println("Size: " + c1.size());

        for (int i = 0; i < c1.size(); i++) 
            System.out.println("Elemento: " + c1.get(i));

        ArrayList<String> c2 = new ArrayList<>();
        c2.add("Vento");
        c2.add("Calor");
        c2.add("Frio");
        c2.add("Chuva");

        System.out.println(c2);
        Collections.sort(c2);
        System.out.println(c2);

        c2.remove("Frio"); 
        c2.remove(0);

        System.out.println(c2);

        ArrayList<String> ex1 = new ArrayList<>();
        ex1.add("Olá!");
        ex1.add("Chamo-me");
        ex1.add("Matilde!");

        System.out.println("Contém Olá! : " + ex1.contains("Olá!"));
        System.out.println("Contém Adeus! : " + ex1.contains("Adeus!"));

        System.out.println("Primeiro index de Matilde! : " + ex1.indexOf("Matilde!"));

        ex1.add("Matilde!");
        System.out.println("Último index de Matilde! : " + ex1.lastIndexOf("Matilde!"));

        ex1.set(3, "Adeus!");
        System.out.println(ex1);

        System.out.println(ex1.subList(1,3)); // 1 e 2

        Set<Pessoa> c3 = new HashSet<>();


    }
}