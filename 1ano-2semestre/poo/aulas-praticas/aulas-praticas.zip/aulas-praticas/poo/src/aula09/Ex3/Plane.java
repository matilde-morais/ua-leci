package aula09.Ex3;

abstract class Plane {

    // ATRIBUTOS

    private String id;
    private String fabricante;
    private String modelo;
    private int anoProd;
    private int maxPassag;
    private int velocMax;

    // CONSTRUTOR
    
    public Plane(String id, String fabricante, String modelo, int anoProd, int maxPassag, int velocMax) {
        
        // VALIDAÇÃO

        if (id != null && fabricante != null && modelo != null && anoProd > 0 && maxPassag > 0 && velocMax > 0) {
            this.id = id;
            this.fabricante = fabricante;
            this.modelo = modelo;
            this.anoProd = anoProd;
            this.maxPassag = maxPassag;
            this.velocMax = velocMax;
        } else {
            throw new IllegalArgumentException("Características Inválidas!");
        }

    }

    // SETTERS

    public void setId (String id) {
        if (id != null) {
            this.id = id;
        } else {
            throw new IllegalArgumentException("Identificação Inválida!");
        }
    }

    public void fabricante (String fabricante) {
        if (modelo != null) {
            this.fabricante = fabricante;
        } else {
            throw new IllegalArgumentException("Fabricante Inválido!");
        }
    }

    public void setModelo (String modelo) {
        if (modelo != null) {
            this.modelo = modelo;
        } else {
            throw new IllegalArgumentException("Modelo Inválido!");
        }
    }


    public void setAnoProd (int anoProd) {
        if (anoProd > 0) {
            this.anoProd = anoProd;
        } else {
            throw new IllegalArgumentException("Ano de Produção Inválido!");
        }
    }

    public void setMaxPassag (int maxPassag) {
        if (maxPassag > 0) {
            this.maxPassag = maxPassag;
        } else {
            throw new IllegalArgumentException("Número Máximo de Passageiros Inválido!");
        }
    }

    public void setVelocMax (int velocMax) {
        if (velocMax > 0) {
            this.velocMax = velocMax;
        } else {
            throw new IllegalArgumentException("Velocidade Máxima Inválida!");
        }
    }

    // GETTERS

    public String getId(){
        return id;
    }

    public String getFabricante(){
        return fabricante;
    }

    public String getModelo(){
        return modelo;
    }

    public int getAnoProd(){
        return anoProd;
    }

    public int getMaxPassag(){
        return maxPassag;
    }

    public int getVelocMax(){
        return velocMax;
    }

    abstract String getPlaneType();

    // MÉTODOS

    public String toString(){
        return "Identificação: " + id + "Fabricante: " + fabricante + "Modelo: " + modelo + "Ano de Produção: " + anoProd + "Número Máximo de Passageiros: " + maxPassag + "Velocidade Máxima: " + velocMax;
    }
}
