package aula09.Ex3;

public class CommercialPlane extends Plane {

    // ATRIBUTOS
    
    private int numTripul;

    // CONSTRUTOR

    public CommercialPlane(String id, String fabricante, String modelo, int anoProd, int maxPassag, int velocMax, int numTripul){
        super(id, fabricante, modelo, anoProd, maxPassag, velocMax);
        
        // VALIDAÇÃO

        if (numTripul > 0) {
            this.numTripul = numTripul;
        } else  {
            throw new IllegalArgumentException("Características Inválidas!")
        }
    }

    


}
