package aula11.Ex1;

public class paresPalavras {
    
}
