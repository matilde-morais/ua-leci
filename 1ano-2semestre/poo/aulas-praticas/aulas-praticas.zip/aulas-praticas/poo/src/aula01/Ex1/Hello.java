package aula01.Ex1;

public class Hello { 
    public static void main(String[] args) { 
        System.out.println("Hello, World!"); 
    } 
} 

// public class Hello {
//    public static void main(String[] args) {
//      String frase = "Hello, World!";
//      System.out.println(frase);
//    }
// }