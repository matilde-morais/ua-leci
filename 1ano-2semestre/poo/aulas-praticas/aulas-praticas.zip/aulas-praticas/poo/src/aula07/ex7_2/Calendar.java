package aula07.ex7_2;

import aula05.DateYMD;

public class Calendar {

    private int year;
    private String[][] events;
    private int firstWeekDay;

    public Calendar(int year, int firstWeekDay) {
        this.year = year;
        this.firstWeekDay = firstWeekDay;
        this.events = new String[12][];
        for (int i = 0; i < 12; i++) {
            this.events[i] = new String[DateYMD.monthDays(i + 1, year)];
        }
    }

    public int year() {
        return year;
    }

    public int firstWeekDay() {
        return firstWeekDay;
    }

    public int firstWeekdayOfMonth(int month) {
        int days = 0;
        for (int i = 0; i < month - 1; i++) {
            days += DateYMD.monthDays(i + 1, year);
        }
        return (days + firstWeekDay) % 7;
    }

    public void addEvent(DateYMD date, String event) {
        events[date.getMonth() - 1][date.getDay() - 1] = event;
    }

    public void removeEvent(DateYMD date) {
        events[date.getMonth() - 1][date.getDay() - 1] = null;
    }

    public String printMonth(int month) {
        StringBuilder sb = new StringBuilder();
        sb.append(monthName(month)).append(" ").append(year).append("\n");
        sb.append("Su Mo Tu We Th Fr Sa\n");
        int firstWeekday = firstWeekdayOfMonth(month);
        for (int i = 0; i < firstWeekday; i++) {
            sb.append("   ");
        }
        for (int day = 1; day <= DateYMD.monthDays(month, year); day++) {
            if (events[month - 1][day - 1] != null) {
                sb.append("*");
            } else {
                sb.append(" ");
            }
            sb.append(String.format("%2d", day));
            if ((firstWeekday + day) % 7 == 0) {
                sb.append("\n");
            } else {
                sb.append(" ");
            }
        }
        sb.append("\n");
        return sb.toString();
    }

    public String printCalendar() {
        StringBuilder sb = new StringBuilder();
        for (int month = 1; month <= 12; month++) {
            sb.append(printMonth(month)).append("\n");
        }
        return sb.toString();
    }

    private String monthName(int month) {
        switch (month) {
            case 1: return "Janeiro";
            case 2: return "Fevreiro";
            case 3: return "Março";
            case 4: return "Abril";
            case 5: return "Maio";
            case 6: return "Junho";
            case 7: return "Julho";
            case 8: return "Agosto";
            case 9: return "Setembro";
            case 10: return "Outubro";
            case 11: return "Novembro";
            case 12: return "Dezembro";
            default: return "";
        }
    }
}
