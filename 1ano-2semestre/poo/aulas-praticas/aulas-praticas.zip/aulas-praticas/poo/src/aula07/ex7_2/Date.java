package aula07.ex7_2;

public abstract class Date {
    
    public abstract int getDay();
    public abstract int getMonth();
    public abstract int getYear();
    public abstract void setDate(int day, int month, int year);

    public static boolean validMonth(int month) {
        return month >= 1 && month <= 12;
    }

    public static int monthDays(int month, int year) {
        if (validMonth(month)) {
            if (month == 2) {
                if (leapYear(year)) {
                    return 29;
                } else {
                    return 28;
                }
            } else if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                return 31;
            } else {
                return 30;
            }
        } else {
            throw new IllegalArgumentException("Mês Inválido!");
        }
    }

    public static boolean leapYear(int year) {
        return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
    }

    public static boolean valid(int day, int month, int year) {
        if (year < 0) {
            return false;
        } else if  (month < 1 || month > 12) {
            return false;
        } else if (day < 1 || day > monthDays(month, year)) {
            return false;
        } else {
            return true;
        }
    }
    
}
