package aula07.ex7_1;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class MainFormas {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        List<Forma> formas = new ArrayList<>();

        int opcao;
        String cor;

        do {
            System.out.println("Escolha uma opção:");
            System.out.println("1. Criar um círculo");
            System.out.println("2. Criar um triângulo");
            System.out.println("3. Criar um retângulo");
            System.out.println("4. Listar formas");
            System.out.println("5. Comparar figuras");
            System.out.println("6. Sair");
            System.out.print("Opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Raio: ");
                    double raio = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Digite a cor do círculo: ");
                    cor = scanner.nextLine();
                    Circulo circulo = new Circulo(raio, cor);
                    formas.add(circulo);
                    System.out.println(circulo.toString());
                    System.out.println("Área: " + circulo.area());
                    System.out.println("Perímetro: " + circulo.perimetro());
                    break;
                case 2:
                    System.out.println("Lado 1: ");
                    double lado1 = scanner.nextDouble();
                    System.out.println("Lado 2: ");
                    double lado2 = scanner.nextDouble();
                    System.out.println("Lado 3: ");
                    double lado3 = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Digite a cor do triângulo: ");
                    cor = scanner.nextLine();
                    Triangulo triangulo = new Triangulo(lado1, lado2, lado3, cor);
                    formas.add(triangulo);
                    System.out.println(triangulo.toString());
                    System.out.println("Área: " + triangulo.area());
                    System.out.println("Perímetro: " + triangulo.perimetro());
                    break;
                case 3:
                    System.out.println("Base: ");
                    double base = scanner.nextDouble();
                    System.out.println("Altura: ");
                    double altura = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Digite a cor do retângulo: ");
                    cor = scanner.nextLine();
                    Retangulo retangulo = new Retangulo(base, altura, cor);
                    formas.add(retangulo);
                    System.out.println(retangulo.toString());
                    System.out.println("Área: " + retangulo.area());
                    System.out.println("Perímetro: " + retangulo.perimetro());
                    break;
                case 4:
                    System.out.println("Listar formas");
                    for (Forma forma : formas) {
                        System.out.println(forma);
                    }
                    break;
                case 5:
                    System.out.println("Comparar figuras");
                    System.out.println("Escolha a primeira figura:");
                    for (int i = 0; i < formas.size(); i++) {
                        System.out.println(i + ". " + formas.get(i));
                    }
                    int indice1 = scanner.nextInt();
                    System.out.println("Escolha a segunda figura:");
                    for (int i = 0; i < formas.size(); i++) {
                        System.out.println(i + ". " + formas.get(i));
                    }
                    int indice2 = scanner.nextInt();
                    Forma forma1 = formas.get(indice1);
                    Forma forma2 = formas.get(indice2);
                    if (forma1.equals(forma2)) {
                    System.out.println("As figuras são iguais!");
                    } else {
                        System.out.println("As figuras são diferentes!");
                    }
                    break;
                case 6:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 6);

        scanner.close();
    }

}
