package aula07.ex7_1;

class Circulo extends Forma {

    // ATRIBUTOS
    
    private double raio;

    public Circulo(double raio, String cor) {
        super(cor);

        // VALIDAÇÃO

        if (raio > 0) {
            this.raio = raio;
        } else {
            throw new IllegalArgumentException("Raio Inválido!");
        }
    }

    // SETTERS

    public void setRaio(double raio) {
        if (raio > 0) {
            this.raio = raio;
        } else {
            throw new IllegalArgumentException("Raio Inválido!");
        }
    }

    // GETTERS

    public double getRaio() {
        return raio;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Circulo - " + super.toString() + " [raio=" + raio + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Circulo) {
                Circulo outro = (Circulo) obj;
                return this.raio == outro.raio;
        }
        return false;
    }

    @Override
    public double area() {
        return Math.PI * Math.pow(raio, 2);
    }

    @Override
    public double perimetro() {
        return 2 * Math.PI * raio;
    }

}