package aula07.ex7_1;

class Triangulo extends Forma {
    
    // ATRIBUTOS
    
    private double lado1;
    private double lado2;
    private double lado3;

    public Triangulo(double lado1, double lado2, double lado3, String cor) {
        super(cor);

        // VALIDAÇÃO    

        if (lado1 > 0 && lado2 > 0 && lado3 > 0 && isValidTriangulo(lado1, lado2, lado3)) {
            this.lado1 = lado1;
            this.lado2 = lado2;
            this.lado3 = lado3;
        } else {
            throw new IllegalArgumentException("Lados Inválidos!");
        }
    }

    private boolean isValidTriangulo(double lado1, double lado2, double lado3) {
        return (lado1 + lado2 > lado3) && (lado1 + lado3 > lado2) && (lado2 + lado3 > lado1);
    }

    // SETTERS

    public void setLado1(double lado1) {
        if (lado1 > 0 && isValidTriangulo(lado1, lado2, lado3))  {
            this.lado1 = lado1;
        } else {
            throw new IllegalArgumentException("Lado Inválido!");
        }
    }

    public void setLado2(double lado2) {
        if (lado2 > 0) {
            this.lado2 = lado2;
        } else {
            throw new IllegalArgumentException("Lado Inválido!");
        }
    }

    public void setLado3(double lado3) {
        if (lado3 > 0) {
            this.lado3 = lado3;
        } else {
            throw new IllegalArgumentException("Lado Inválido!");
        }
    }

    // GETTERS  

    public double getLado1() {
        return lado1;
    }

    public double getLado2() {
        return lado2;
    }

    public double getLado3() {
        return lado3;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Triângulo - " + super.toString() + ", Lados: " + lado1 + ", " + lado2 + ", " + lado3;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Triangulo) {
            Triangulo outro = (Triangulo) obj;
            return this.lado1 == outro.lado1 && this.lado2 == outro.lado2 && this.lado3 == outro.lado3;
        } else {
            return false;
        }
    }

    @Override
    public double area() {
        double p = (lado1 + lado2 + lado3) / 2;
        return Math.sqrt(p * (p - lado1) * (p - lado2) * (p - lado3));
    }

    @Override
    public double perimetro() {
        return lado1 + lado2 + lado3;
    }

}