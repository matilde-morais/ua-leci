package aula07.ex7_2;

public class DateND extends Date {

    private int daysFrom2000;

    public DateND(int daysFrom2000) {

        if (daysFrom2000 >= 0) {
            this.daysFrom2000 = daysFrom2000;
        } else {
            throw new IllegalArgumentException("Data Inválida!");
        }
    }

    @Override
    public int getDay() {
        int year = 2000;
        int month = 1;
        int day = 1;
        while (daysFrom2000 > 0) {
            int daysInMonth = Date.monthDays(month, year);
            if (daysFrom2000 >= daysInMonth) {
                daysFrom2000 -= daysInMonth;
                month++;
                if (month > 12) {
                    month = 1;
                    year++;
                }
                day = 1;
            } else {
                day += daysFrom2000;
                daysFrom2000 = 0;
            }
        }
        return day;
    }

    @Override
    public int getMonth() {
        int year = 2000;
        int month = 1;
        while (daysFrom2000 > 0) {
            int daysInMonth = Date.monthDays(month, year);
            if (daysFrom2000 >= daysInMonth) {
                daysFrom2000 -= daysInMonth;
                month++;
                if (month > 12) {
                    month = 1;
                    year++;
                }
            } else {
                break;
            }
        }
        return month;
    }

    @Override
    public int getYear() {
        int year = 2000;
        int month = 1;
        while (daysFrom2000 > 0) {
            int daysInMonth = Date.monthDays(month, year);
            if (daysFrom2000 >= daysInMonth) {
                daysFrom2000 -= daysInMonth;
                month++;
                if (month > 12) {
                    month = 1;
                    year++;
                }
            } else {
                break;
            }
        }
        return year;
    }

    @Override
    public void setDate(int day, int month, int year) {
        int daysSince2000 = 0;
        for (int y = 2000; y < year; y++) {
            daysSince2000 += Date.leapYear(y) ? 366 : 365;
        }
        for (int m = 1; m < month; m++) {
            daysSince2000 += Date.monthDays(m, year);
        }
        daysSince2000 += day - 1;
        this.daysFrom2000 = daysSince2000;
    }

    @Override
    public String toString() {
        return "DateND: " + getYear() + "-" + getMonth() + "-" + getDay();
    }
}
