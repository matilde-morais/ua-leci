package aula07.ex7_1;

class Retangulo extends Forma {
    
    // ATRIBUTOS

    private double base;
    private double altura;

    public Retangulo(double base, double altura, String cor) {  
        super(cor);

        // VALIDAÇÃO

        if (base > 0 && altura > 0) {
            this.base = base;
            this.altura = altura;
        } else {
            throw new IllegalArgumentException("Base e/ou Altura Inválidos!");
        }
    }

    // SETTERS

    public void setBase(double base) {
        if (base > 0) {
            this.base = base;
        } else {
            throw new IllegalArgumentException("Base Inválida!");
        }
    }

    public void setAltura(double altura) {
        if (altura > 0) {
            this.altura = altura;
        } else {
            throw new IllegalArgumentException("Altura Inválida!");
        }
    }

    // GETTERS

    public double getBase() {
        return base;
    }

    public double getAltura() {
        return altura;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Retângulo - " + super.toString() + ", Comprimento: " + base + ", Altura: " + altura;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Retangulo) {
            Retangulo outro = (Retangulo) obj;
            return this.base == outro.base && this.altura == outro.altura;
        }
        return false;
    }

    public double area() {
        return base * altura;
    }

    public double perimetro() {
        return 2 * (base + altura);
    }

}
