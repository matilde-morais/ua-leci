package aula07.ex7_1;

abstract class Forma {

    // ATRIBUTOS

    protected String cor;

    public Forma(String cor) {

        // VALIDAÇÃO

        if (cor != null) {
            this.cor = cor;
        } else {
            throw new IllegalArgumentException("Cor Inválida!");
        }
    }

    public abstract double area();
    public abstract double perimetro();

    // SETTERS

    public void setCor(String cor) {
        if (cor != null) {
            this.cor = cor;
        } else {
            throw new IllegalArgumentException("Cor Inválida!");
        }
    }

    // GETTERS

    public String getCor() {
        return cor;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Forma [cor=" + cor + "]";
    }
    
}