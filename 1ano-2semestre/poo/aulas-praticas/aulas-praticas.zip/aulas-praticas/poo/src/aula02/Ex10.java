package aula02;

import java.util.ArrayList; // import the ArrayList class
import java.util.Scanner;

public class Ex10 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<Double> numeros = new ArrayList<>(); // Create an ArrayList object

        System.out.println(" Introduza o conjunto de valores, terminado com um valor igual ao primeiro introduzido.");
        while (true) {
            System.out.println("Introduza um valor: ");
            double numero = scanner.nextDouble();

            if (numeros.size()>0 && numero == numeros.get(0)) { // termina o ciclo // && = and
                break;
            }

            numeros.add(numero);

        }

        double maximo = Double.MIN_VALUE;
        double minimo = Double.MAX_VALUE;
        double soma = 0;
        for (double numero : numeros) { // for each number in the list
            if (numero > maximo) {
                maximo = numero;
            }

            if (numero < minimo) {
                minimo = numero;
            }

            soma += numero;
        }

        double media = soma/numeros.size();

        System.out.println("Máximo: " + maximo);
        System.out.println("Mínimo: " + minimo);
        System.out.println("Média: " + media);
        System.out.println("Quatidade de números: " + numeros.size());

        scanner.close();

    }

}
