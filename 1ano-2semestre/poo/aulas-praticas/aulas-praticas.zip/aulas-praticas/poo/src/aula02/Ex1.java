package aula02;

import java.util.Scanner;

public class Ex1 { // declaração da classe

    public static void main(String[] args) { // método principal

        Scanner scanner = new Scanner(System.in); // cria um objeto Scanner para ler da entrada padrão

        System.out.println("Insira a distância em quilómetros (usar vírgula para números decimais): "); // imprime uma mensagem
        double quilometros = scanner.nextDouble(); // lê um número real da entrada padrão

        double milhas = quilometros / 1.609; // converte quilómetros para milhas

        System.out.println("A distância em milhas é:\n" + milhas); // imprime o resultado (distância em milhas)

        scanner.close(); // fecha o objeto Scanner

    }

}
