package aula02;

import java.util.Scanner;

public class Ex7 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Insira as coordenadas do primeiro ponto (p1).");
        System.out.println("Coordenada x: ");
        double x1 = scanner.nextDouble();
        System.out.print("Coordenada y: ");
        double y1 = scanner.nextDouble();
        
        System.out.println("Insira as coordenadas do segundo ponto (p2).");
        System.out.print("Coordenada x: ");
        double x2 = scanner.nextDouble();
        System.out.print("Coordenada y: ");
        double y2 = scanner.nextDouble();
        
        // Distância entre dois pontos: d=√((x2-x1)²+(y2-y1)²)
        double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)); // Math.pow(base, expoente)
        
        System.out.printf("A distância entre os pontos é: %.2f", distancia);
        // .2f especifica que um número de ponto flutuante deve ser formatado com duas casas decimais após o ponto decimal
        
        scanner.close(); 

    }

}
