package aula02;

import java.util.Scanner;

public class Ex2 {
   
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println(" Insira a temperatura em graus Celsius (usar vírgula para números decimais): ");

        double celsius = scanner.nextDouble();

        double fahrenheit = celsius*1.8 + 32;

        System.out.println("A temperatura em graus Fahrenheit é:\n" + fahrenheit);

        scanner.close();

    }

}
