package aula02;

import java.util.Scanner;

public class Ex4 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira o montante investido, em euros (usar vírgula para números decimais): ");

        double montante = scanner.nextDouble();

        System.out.println("Insira a taxa de juro mensal, em percentagem (usar vírgula para números decimais): ");

        double taxaJuro = scanner.nextDouble();

        double taxa = taxaJuro/100;

        double total1 = (montante*taxa) + montante;

        double total2 = (total1*taxa) + total1;

        double total3 = (total2*taxa) + total2;

        System.out.println("O montante após 3 meses é:\n" + total3 + " euros");

        scanner.close();

    }

}
