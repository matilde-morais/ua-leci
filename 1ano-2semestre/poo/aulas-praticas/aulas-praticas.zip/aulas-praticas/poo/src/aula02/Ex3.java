package aula02;

import java.util.Scanner;

public class Ex3 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira a quantidade de água, em Kg (usar vírgula para números decimais): ");

        double M = scanner.nextDouble();

        System.out.println("Insira a temperatura inicial da água, em Celsius (usar vírgula para números decimais): ");

        double tempInicial = scanner.nextDouble();

        System.out.println("Insira a temperatura final desejada da água, em Celsius (usar vírgula para números decimais): ");

        double tempFinal = scanner.nextDouble();

        double Q = M*(tempFinal - tempInicial)*4184;

        System.out.println("A quantidade de energia necesssária para aquecer a água é:\n" + Q + " Joules");

        scanner.close();

    }

}
