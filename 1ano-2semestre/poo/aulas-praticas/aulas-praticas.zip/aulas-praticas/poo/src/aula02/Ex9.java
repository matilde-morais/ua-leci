package aula02;

import java.util.ArrayList;
import aula02.Ex11;

public class Ex9 {
    
    public static void main(String[] args) {
        int N = Ex11.getInWithinRange("Insira um valor positivo", 1, Integer.MAX_VALUE); // get an integer within a range, from 1 to the maximum value of an integer
        ArrayList<Integer> numeros = new ArrayList<>(); // Create an ArrayList object
        
        for (int i = N; i >= 0; i--) {
            System.out.print(i);
            if (i > 0) {
                System.out.print(",");
            }
            if (i % 10 == 0 && i != 0) {
                System.out.println();
            }
        }
    }
}