package aula02;

import java.util.Scanner;

public class Ex11 {
    
    private static Scanner scanner = new Scanner(System.in); // Create a Scanner object

    public static int getInWithinRange(String prompt, int min, int max) { // get an integer within a range

        int input;

        do { // do while loop
            System.out.print(prompt + " (entre " + min + " e " + max + "): "); 
            while (!scanner.hasNextInt()) { // while the input is not an integer // ! = not
                System.out.println("Por favor, insira um valor inteiro válido.");
                System.out.print(prompt + " (entre " + min + " e " + max + "): ");
                scanner.next(); // discard the input
            }
            input = scanner.nextInt(); // read the input
            if (input < min || input > max) { // if the input is out of range
                System.out.println("O valor inserido está fora do intervalo permitido.");
            }
        } while (input < min || input > max); // while the input is out of range
        return input;

    }

}
