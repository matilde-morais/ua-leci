package aula02;

import java.util.Scanner;

public class Ex6 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira um tempo, em segundos: ");

        int tempo = scanner.nextInt();

        if (tempo < 0) {
            System.out.println("O tempo não pode ser negativo.");
            return;
        }

        int horas = tempo/3600;
        int minutos = (tempo%3600)/60;
        int segundos = (tempo%3600)%60;

        System.out.printf("Tempo formatado: %02d:%02d:%02d%n", horas, minutos, segundos);

        scanner.close();

    }

}
