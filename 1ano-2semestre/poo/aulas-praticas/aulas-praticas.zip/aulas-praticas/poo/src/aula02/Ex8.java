package aula02;

import java.util.Scanner;

public class Ex8 {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Insira o valor do cateto A: ");
        double catetoA = scanner.nextDouble();
        System.out.println("Insira o valor do cateto B: ");
        double catetoB = scanner.nextDouble();
        
        if (catetoA <= 0 || catetoB <= 0) { // || é o operador lógico "ou"
            System.out.println("Os valores dos catetos devem ser positivos.");
            return;
        }
        
        // hipotenusa = √(catetoA² + catetoB²)
        double hipotenusa = Math.sqrt(Math.pow(catetoA, 2) + Math.pow(catetoB, 2));
        
        // angulo = arctan(catetoA / catetoB)
        double anguloRad = Math.atan(catetoA / catetoB); // Math.atan(x) > acrtan(x)
        double anguloGraus = Math.toDegrees(anguloRad); // Math.toDegrees(x) > converte x de radianos para graus
        
        System.out.printf("O valor da hipotenusa é: %.2f%n", hipotenusa);
        System.out.printf("O valor do ângulo entre o lado A e a hipotenusa é: %.2f graus%n", anguloGraus);
        
        scanner.close();

    }

}
