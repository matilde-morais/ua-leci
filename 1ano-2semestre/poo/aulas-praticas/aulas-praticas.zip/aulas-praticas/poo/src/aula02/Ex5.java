package aula02;

import java.util.Scanner;

public class Ex5 {

    public static void main(String[] args) {
    
        Scanner scanner = new Scanner(System.in);

        System.out.println("Insira a velocidade do primeiro trajeto: ");

        double v1 = scanner.nextDouble();
        if (v1 < 0) {
            System.out.println("A velocidade não pode ser negativa.");
            return;
        }

        System.out.println("Insira a distância percorrida no primeiro trajeto: ");  

        double d1 = scanner.nextDouble();
        if (d1 < 0) {
            System.out.println("A distância não pode ser negativa.");
            return;
        }

        System.out.println("Insira a velocidade do segundo trajeto: ");

        double v2 = scanner.nextDouble();
        if (v2 < 0) {
            System.out.println("A velocidade não pode ser negativa.");
            return;
        }

        System.out.println("Insira a distância percorrida no segundo trajeto: ");

        double d2 = scanner.nextDouble();
        if (d2 < 0) {
            System.out.println("A distância não pode ser negativa.");
            return;
        }

        double tempoTotal = (d1 / v1) + (d2 / v2);
            
        double velocidadeMedia = (d1 + d2) / tempoTotal;
        
        System.out.println("A velocidade média de transporte é:\n" + velocidadeMedia + " km/h");
        
        scanner.close();

    }

}
