package aula10.Ex2;

public class Livro extends Generos {

    // ATRIBUTOS
    
    private String titulo;
    private String autor;
    private int ano;

    // CONSTRUTOR

    public Livro(String titulo, String autor, int ano) {

        // VALIDAÇÃO
        if (titulo != null && autor != null && ano > 0) {
            this.titulo = titulo;
            this.autor = autor;
            this.ano = ano;
        } else {
            throw new IllegalArgumentException("Dados Inválidos!");
        }
    }

    // SETTERS

    public void setTitulo(String titulo) {
        if (titulo != null) {
            this.titulo = titulo;
        } else {
            throw new IllegalArgumentException("Título Inválido!");
        }
    }

    public void setAutor(String autor) {
        if (autor != null) {
            this.autor = autor;
        } else {
            throw new IllegalArgumentException("Autor Inválido!");
        }
    }

    public void setAno(int ano) {
        if (ano > 0) {
            this.ano = ano;
        } else {
            throw new IllegalArgumentException("Ano Inválido!");
        }
    }

    // GETTERS

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAno() {
        return ano;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Título: " + titulo + "\nAutor: " + autor + "\nAno: " + ano;
    }

}
