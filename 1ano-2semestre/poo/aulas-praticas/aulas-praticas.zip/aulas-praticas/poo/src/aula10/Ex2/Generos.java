package aula10.Ex2;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.LinkedHashMap;

public class Generos {

    // ATRIBUTOS

    private LinkedHashMap<String, List<Livro>> generosMapa;

    // CONSTRUTOR

    public Generos() {
        generosMapa = new LinkedHashMap<>();
    }

    // SETTERS

    public void adicionarLivro(String genero, Livro livro) {
        if (!generosMapa.containsKey(genero)) {
            generosMapa.put(genero, new ArrayList<>());
        }
        generosMapa.get(genero).add(livro);
    }

    // MÉTODOS

    public void updateLivro(String genero, int indice, Livro novoLivro) {
        if (generosMapa.containsKey(genero) && indice >= 0 && indice < generosMapa.get(genero).size()) {
            generosMapa.get(genero).set(indice, novoLivro);
        } else {
            System.out.println("Género ou Índice Inválidos!");
        }
    }

    public void apagarLivro(String genero, int indice) {
        if (generosMapa.containsKey(genero) && indice >= 0 && indice < generosMapa.get(genero).size()) {
            generosMapa.get(genero).remove(indice);
        } else {
            System.out.println("Género ou Índice Inválidos!");
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Biblioteca:\n");
        for (Map.Entry<String, List<Livro>> entry : generosMapa.entrySet()) {
            sb.append(entry.getKey()).append(": \n").append(entry.getValue()).append("\n");
        }
        return sb.toString();
    }

}