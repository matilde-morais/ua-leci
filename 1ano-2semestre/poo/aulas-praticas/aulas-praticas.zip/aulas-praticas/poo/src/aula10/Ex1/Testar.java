package aula10.Ex1;

public class Testar {
    
    public static void main(String[] args) {
        Generos biblioteca = new  Generos();

        // Adicionar livros de exemplo
        biblioteca.adicionarLivro("Drama", new Livro("Hamlet", "William Shakespeare", 1603));
        biblioteca.adicionarLivro("Drama", new Livro("To Kill a Mockingbird", "Harper Lee", 1960));
        biblioteca.adicionarLivro("Fantasy", new Livro("The Hobbit", "J.R.R. Tolkien", 1937));
        biblioteca.adicionarLivro("Fantasy", new Livro("Harry Potter and the Philosopher's Stone", "J.K. Rowling", 1997));
        biblioteca.adicionarLivro("Science Fiction", new Livro("Dune", "Frank Herbert", 1965));

        // Imprimir a estrutura completa
        System.out.println(biblioteca);

        // Imprimir apenas os géneros
        biblioteca.mostrarGeneros();

        // Imprimir apenas os livros
        biblioteca.mostrarLivros();

        // Exemplo de atualização de livro
        biblioteca.updateLivro("Drama", 1, new Livro("Romeo and Juliet", "William Shakespeare", 1597));
        System.out.println("\nApós a atualização:");
        System.out.println(biblioteca);

        // Exemplo de remoção de livro
        biblioteca.apagarLivro("Fantasy", 0);
        System.out.println("\nApós a remoção:");
        System.out.println(biblioteca);
    }
    
}
