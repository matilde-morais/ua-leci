package aula08.Ex1;

public class PesadosMercadorias extends Pesados {
    
    // ATRIBUTOS

    protected int cargaMaxima;

    // CONSTRUTOR

    public PesadosMercadorias(String matricula, String marca, String modelo, int potenciaCV, int ultimoTrajeto, int distanciaTotal, int numQuadro, int peso, int cargaMaxima) {
        super(matricula, marca, modelo, potenciaCV, ultimoTrajeto, distanciaTotal, numQuadro, peso);

        // VALIDAÇÃO

        if (cargaMaxima > 0) {
            this.cargaMaxima = cargaMaxima;
        } else {
            throw new IllegalArgumentException("Características Inválidas!");
        }
    }

    // SETTERS

    public void setCargaMaxima(int cargaMaxima) {
        if (cargaMaxima > 0) {
            this.cargaMaxima = cargaMaxima;
        } else {
            throw new IllegalArgumentException("Carga Máxima Inválida!");
        }
    }

    // GETTERS

    public int getCargaMaxima() {
        return cargaMaxima;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return super.toString() + "\n Carga Máxima: " + cargaMaxima;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof PesadosMercadorias) {
            PesadosMercadorias pm = (PesadosMercadorias) obj;
            return super.equals(pm) && cargaMaxima == pm.getCargaMaxima();
        }
        return false;
    }
}
