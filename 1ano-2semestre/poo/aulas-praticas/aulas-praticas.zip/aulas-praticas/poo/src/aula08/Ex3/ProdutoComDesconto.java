package aula08.Ex3;

public class ProdutoComDesconto implements Produto {

    // ATRIBUTOS

    private String nome;
    private int quantidade;
    private double preco;
    private double desconto;

    // CONSTRUTOR

    public ProdutoComDesconto(String nome, int quantidade, double preco, double desconto) {
        this.nome = nome;
        this.quantidade = quantidade;
        this.preco = preco;
        this.desconto = desconto;
    }

    // SETTERS
    
    @Override
    public void adicionarQuantidade(int quantidade) {
        this.quantidade += quantidade;
    }

    @Override
    public void removerQuantidade(int quantidade) {
        this.quantidade -= quantidade;
    }

    // GETTERS

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public double getPreco() {
        return preco - desconto;
    }

    @Override
    public int getQuantidade() {
        return quantidade;
    }

}