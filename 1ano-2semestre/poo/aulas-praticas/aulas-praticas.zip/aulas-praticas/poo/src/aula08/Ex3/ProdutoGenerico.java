package aula08.Ex3;

public class ProdutoGenerico implements Produto {

    // ATRIBUTOS

    private String nome;
    private int quantidade;
    private double preco;

    // CONSTRUTOR

    public ProdutoGenerico(String nome, int quantidade, double preco) {

        // VALIDAÇÃO
        
        if(nome != null && quantidade >= 0 && preco > 0) {
            this.nome = nome;
            this.quantidade = quantidade;
            this.preco = preco;
        } else {
            throw new IllegalArgumentException("Valores Inválidos!");
        }
    }

    // SETTERS

    @Override
    public void adicionarQuantidade(int quantidade) {
        this.quantidade += quantidade;
    }

    @Override
    public void removerQuantidade(int quantidade) {
        this.quantidade -= quantidade;
    }

    // GETTERS

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public double getPreco() {
        return preco;
    }

    @Override
    public int getQuantidade() {
        return quantidade;
    }
}