package aula08.Ex2;

public class PratoVegetariano extends Prato {

    // CONSTRUTOR

    public PratoVegetariano(String nome) {
        super(nome);
    }

    // MÉTODOS

    @Override
    public String toString() {
        return String.format("%s - Prato Vegetariano", super.toString());
    }
}