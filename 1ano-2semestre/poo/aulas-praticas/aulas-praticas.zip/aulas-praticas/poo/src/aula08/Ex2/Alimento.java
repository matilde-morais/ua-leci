package aula08.Ex2;

interface Alimento extends Comparable<Alimento> {
    String getNome();
    double getProteinas();
    double getCalorias();
    double getPeso();
}
