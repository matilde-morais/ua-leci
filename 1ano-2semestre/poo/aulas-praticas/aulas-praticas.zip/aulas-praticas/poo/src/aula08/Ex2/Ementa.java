package aula08.Ex2;

import java.util.*;

public class Ementa {

    // ATRIBUTOS
    private String nome;
    private String local;
    private Map<Ementa.DiaSemana, Prato> pratos;

    // CONSTRUTOR

    public Ementa(String nome, String local) {

        if (nome == null || nome.trim().isEmpty() || local == null || local.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome e local da ementa inválidos!");
        }
        this.nome = nome;
        this.local = local;
        this.pratos = new HashMap<>();
    }

    // SETTERS

    public void addPrato(Prato prato, Ementa.DiaSemana dia) {
        pratos.put(dia, prato);
    }

    // MÉTODOS

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Ementa final\n");
        sb.append("--------------------\n");
        for (Map.Entry<Ementa.DiaSemana, Prato> entry : pratos.entrySet()) {
            sb.append(entry.getValue()).append(", dia ").append(entry.getKey()).append("\n");
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, local, pratos);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Ementa other = (Ementa) obj;
        return Objects.equals(nome, other.nome) && Objects.equals(local, other.local) && Objects.equals(pratos, other.pratos);
    }

    public enum DiaSemana {
        Segunda, Terca, Quarta, Quinta, Sexta, Sabado, Domingo
    }

}