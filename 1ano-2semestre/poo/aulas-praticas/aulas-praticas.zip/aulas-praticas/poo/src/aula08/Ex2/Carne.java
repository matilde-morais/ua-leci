package aula08.Ex2;

import java.util.Objects;

public class Carne extends AlimentoBasico {

    // ATRIBUTOS

    private String variedade;

    // CONSTRUTOR

    public Carne(String variedade, double proteinas, double calorias, double peso) {
        super("Carne", proteinas, calorias, peso);

        // VALIDAÇÃO
        if (variedade != null && variedade.length() > 0) {
            this.variedade = variedade;
        } else {
            throw new IllegalArgumentException("Variedade Inválida!");
        }
    }

    // GETTERS

    public String getVariedade() {
        return variedade;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return String.format("Carne (%s): Proteinas %.2f, calorias %.2f, Peso %.2f", variedade, proteinas, calorias, peso);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), variedade);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Carne other = (Carne) obj;
        return Objects.equals(variedade, other.variedade);
    }

}