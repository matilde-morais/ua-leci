package aula08.Ex2;

public class PratoDieta extends Prato {

    // ATRIBUTOS

    private double limiteMaxCalorias;

    // CONSTRUTOR

    public PratoDieta(String nome, double limiteMaxCalorias) {
        super(nome);
        this.limiteMaxCalorias = limiteMaxCalorias;
    }

    @Override
    public String toString() {
        return String.format("%s - Dieta (%.2f Calorias)", super.toString(), limiteMaxCalorias);
    }
}