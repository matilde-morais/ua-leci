package aula08.Ex2;

import java.util.*;

public class Peixe extends AlimentoBasico {

    // ATRIBUTOS

    private String tipo;

    // CONSTRUTOR

    public Peixe(String tipo, double proteinas, double calorias, double peso) {
        super("Peixe", proteinas, calorias, peso);

        // VALIDAÇÃO
        if (tipo != null && tipo.length() > 0) {
            this.tipo = tipo;
        } else {
            throw new IllegalArgumentException("Tipo Inválido!");
        }
    }

    // GETTERS

    public String getTipo() {
        return tipo;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return String.format("Peixe (%s): Proteinas %.2f, calorias %.2f, Peso %.2f", tipo, proteinas, calorias, peso);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), tipo);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Peixe other = (Peixe) obj;
        return Objects.equals(tipo, other.tipo);
    }

}