package aula08.Ex1;

public class PesadosPassageiros extends Pesados {

    // ATRIBUTOS

    protected int numMaxPassag;

    // CONSTRUTOR

    public PesadosPassageiros(String matricula, String marca, String modelo, int potenciaCV, int ultimoTrajeto, int distanciaTotal, int numQuadro, int peso, int numMaxPassag) {
        super(matricula, marca, modelo, potenciaCV, ultimoTrajeto, distanciaTotal, numQuadro, peso);

        // VALIDAÇÃO

        if (numMaxPassag > 0) {
            this.numMaxPassag = numMaxPassag;
        } else {
            throw new IllegalArgumentException("Características Inválidas!");
        }
    }

    // SETTERS

    public void setNumMaxPassag(int numMaxPassag) {
        if (numMaxPassag > 0) {
            this.numMaxPassag = numMaxPassag;
        } else {
            throw new IllegalArgumentException("Número Máximo de Passageiros Inválido!");
        }
    }

    // GETTERS

    public int getNumMaxPassag() {
        return numMaxPassag;
    }

    // MÉTODOS

    @Override

    public String toString() {
        return super.toString() + "\n Número Máximo de Passageiros: " + numMaxPassag;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof PesadosPassageiros) {
            PesadosPassageiros pp = (PesadosPassageiros) obj;
            return super.equals(pp) && numMaxPassag == pp.getNumMaxPassag();
        }
        return false;
    }

}