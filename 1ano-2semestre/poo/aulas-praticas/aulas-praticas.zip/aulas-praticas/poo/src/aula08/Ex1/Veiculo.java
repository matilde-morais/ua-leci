package aula08.Ex1;

public abstract class Veiculo implements KmPercorridosInterface {
    
    // ATRIBUTOS

    protected String matricula;
    protected String marca;
    protected String modelo;
    protected int potenciaCV;
    
    protected int quilometros;
    protected int ultimoTrajeto = 0;
    protected int distanciaTotal = 0;

    // CONSTRUTORES

    public Veiculo(String matricula, String marca, String modelo, int potenciaCV, int ultimoTrajeto, int distanciaTotal) {
        
        // VALIDAÇÃO

        if (matricula != null && marca != null && modelo != null && potenciaCV > 0 && ultimoTrajeto >= 0 && distanciaTotal >= 0) {
            this.matricula = matricula;
            this.marca = marca;
            this.modelo = modelo;
            this.potenciaCV = potenciaCV;
            this.ultimoTrajeto = ultimoTrajeto;
            this.distanciaTotal = distanciaTotal;
        } else {
            throw new IllegalArgumentException("Características Inválidas!");
        }
    }

    // SETTERS

    public void setMatricula(String matricula) {
        if (matricula != null) {
            this.matricula = matricula;
        } else {
            throw new IllegalArgumentException("Matrícula Inválida!");
        }
    }

    public void setMarca(String marca) {
        if (marca != null) {
            this.marca = marca;
        } else {
            throw new IllegalArgumentException("Marca Inválida!");
        }
    }

    public void setModelo(String modelo) {
        if (modelo != null) {
            this.modelo = modelo;
        } else {
            throw new IllegalArgumentException("Modelo Inválido!");
        }
    }

    public void setPotenciaCV(int potenciaCV) {
        if (potenciaCV > 0) {
            this.potenciaCV = potenciaCV;
        } else {
            throw new IllegalArgumentException("Potência Inválida!");
        }
    }

    public void trajeto(int quilometros) {
        if (quilometros > 0) {
            this.quilometros = quilometros;
            this.distanciaTotal += quilometros;
            this.ultimoTrajeto = quilometros;
        } else {
            throw new IllegalArgumentException("Quilómetros Inválidos!");
        }
    }

    // GETTERS

    public String getMatricula() {
        return matricula;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getPotenciaCV() {
        return potenciaCV;
    }

    public int ultimoTrajeto() {
        return ultimoTrajeto;
    }

    public int distanciaTotal() {
        return distanciaTotal;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return "Matrícula: " + matricula + "\nMarca: " + marca + "\nModelo: " + modelo + "\nPotência: " + potenciaCV + "CV" + "\nÚltimo Trajeto: " + ultimoTrajeto + "\nDistância Total: " + distanciaTotal;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Veiculo) {
            Veiculo v = (Veiculo) obj;
            return matricula.equals(v.getMatricula()) && marca.equals(v.getMarca()) && modelo.equals(v.getModelo()) && potenciaCV == v.getPotenciaCV();
        } else {
            return false;
        }
    }

}