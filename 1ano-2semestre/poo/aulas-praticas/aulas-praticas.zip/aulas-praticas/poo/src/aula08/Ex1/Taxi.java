package aula08.Ex1;

public class Taxi extends AutoLigeiro {

    // ATRIBUTOS

    protected int numLicenca;

    // CONSTRUTORES

    public Taxi(String matricula, String marca, String modelo, int potenciaCV, int ultimoTrajeto, int distanciaTotal, int numQuadro, int capacBagageira, int numLicenca) {
        super(matricula, marca, modelo, potenciaCV, ultimoTrajeto, distanciaTotal, numQuadro, capacBagageira);

        // VALIDAÇÃO

        if (numLicenca > 0) {
            this.numLicenca = numLicenca;
        } else {
            throw new IllegalArgumentException("Características Inválidas!");
        }
    }

    // SETTERS

    public void setNumLicenca(int numLicenca) {
        if (numLicenca > 0) {
            this.numLicenca = numLicenca;
        } else {
            throw new IllegalArgumentException("Número de Licença Inválido!");
        }
    }

    // GETTERS

    public int getNumLicenca() {
        return numLicenca;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return super.toString() + "\n Número de Licença: " + numLicenca;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Taxi) {
            Taxi t = (Taxi) obj;
            return super.equals(t) && numLicenca == t.getNumLicenca();
        }
        return false;
    }
    
}
