package aula08.Ex1;

public class AutoLigeiro extends Veiculo {
    
    // ATRIBUTOS

    protected int numQuadro;
    protected int capacBagageira;

    // CONSTRUTORES

    public AutoLigeiro(String matricula, String marca, String modelo, int potenciaCV, int numQuadro, int capacBagageira, int ultimoTrajeto, int distanciaTotal) {
        super(matricula, marca, modelo, potenciaCV, ultimoTrajeto, distanciaTotal);

        // VALIDAÇÃO

        if (numQuadro > 0 && capacBagageira > 0) {
            this.numQuadro = numQuadro;
            this.capacBagageira = capacBagageira;
        } else  {
            throw new IllegalArgumentException("Características Inválidas!");
        }
    }

    // SETTERS

    public void setNumQuadro(int numQuadro) {
        if (numQuadro > 0) {
            this.numQuadro = numQuadro;
        } else {
            throw new IllegalArgumentException("Número de Quadro Inválido!");
        }
    }

    public void setCapacBagageira(int capacBagageira) {
        if (capacBagageira > 0) {
            this.capacBagageira = capacBagageira;
        } else {
            throw new IllegalArgumentException("Capacidade de Bagageira Inválida!");
        }
    }

    // GETTERS

    public int getNumQuadro() {
        return numQuadro;
    }

    public int getCapacBagageira() {
        return capacBagageira;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return super.toString() + "\n Número de Quadro: " + numQuadro + "\n Capacidade de Bagageira: " + capacBagageira;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof AutoLigeiro) {
            AutoLigeiro al = (AutoLigeiro) obj;
            return super.equals(al) && numQuadro == al.getNumQuadro() && capacBagageira == al.getCapacBagageira();
        }
        return false;
    }
}
