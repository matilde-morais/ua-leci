package aula08.Ex2;

import java.util.Objects;

abstract class AlimentoBasico implements Alimento {

    // ATRIBUTOS

    protected String nome;
    protected double proteinas;
    protected double calorias;
    protected double peso;

    // CONSTRUTOR

    public AlimentoBasico(String nome, double proteinas, double calorias, double peso) {

        // VALIDAÇÃO

        if (nome != null && nome.length() > 0 && proteinas >= 0 && calorias >= 0 && peso >= 0) {
            this.nome = nome;
            this.proteinas = proteinas;
            this.calorias = calorias;
            this.peso = peso;
        } else {
            throw new IllegalArgumentException("Alimento Inválido!");
        }
    }

    // GETTERS

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public double getProteinas() {
        return proteinas;
    }

    @Override
    public double getCalorias() {
        return calorias;
    }

    @Override
    public double getPeso() {
        return peso;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return String.format("%s: Proteinas %.2f, calorias %.2f, Peso %.2f", nome, proteinas, calorias, peso);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, proteinas, calorias, peso);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        AlimentoBasico other = (AlimentoBasico) obj;
        return Objects.equals(nome, other.nome) && proteinas == other.proteinas
                && calorias == other.calorias && peso == other.peso;
    }

    @Override
    public int compareTo(Alimento outro) {
        return Double.compare(this.getCalorias(), outro.getCalorias());
    }

}