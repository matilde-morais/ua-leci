package aula08.Ex1;

import java.util.ArrayList;
import java.util.List;

public class EmpresaAluguer {
    
    // ATRIBUTOS

    public String nome;
    public String codigoPostal;
    public String email;
    public List<Veiculo> viaturas;

    // CONSTRUTORES 

    public EmpresaAluguer(String nome, String codigoPostal, String email) {
        
        // VALIDAÇÃO

        if (nome != null && codigoPostal != null && email != null) {
            this.nome = nome;
            this.codigoPostal = codigoPostal;
            this.email = email;
            this.viaturas = new ArrayList<>();
        } else {
            throw new IllegalArgumentException("Características Inválidas!");
        }
    }

    // SETTERS

    public void setNome(String nome) {
        if (nome != null) {
            this.nome = nome;
        } else {
            throw new IllegalArgumentException("Nome Inválido!");
        }
    }

    public void setCodigoPostal(String codigoPostal) {
        if (codigoPostal != null) {
            this.codigoPostal = codigoPostal;
        } else {
            throw new IllegalArgumentException("Código Postal Inválido!");
        }
    }

    public void setEmail(String email) {
        if (email != null) {
            this.email = email;
        } else {
            throw new IllegalArgumentException("Email Inválido!");
        }
    }

    // GETTERS

    public String getNome() {
        return nome;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public String getEmail() {
        return email;
    }

    public List<Veiculo> getViaturas() {
        return viaturas;
    }

    // MÉTODOS




}
