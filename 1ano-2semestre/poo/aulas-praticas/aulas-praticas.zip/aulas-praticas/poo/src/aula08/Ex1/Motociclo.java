package aula08.Ex1;

public class Motociclo extends Veiculo {
    
    // ATRIBUTOS

    protected String tipo;

    // CONSTRUTORES

    public Motociclo(String matricula, String marca, String modelo, int potenciaCV, String tipo, int ultimoTrajeto, int distanciaTotal) {
        super(matricula, marca, modelo, potenciaCV, ultimoTrajeto, distanciaTotal);
        
        // VALIDAÇÃO

        if (tipo != null) {
            this.tipo = tipo;
        } else {
            throw new IllegalArgumentException("Tipo Inválido!");
        }
    }

    // SETTERS

    public void setTipo(String tipo) {
        if (tipo != null) {
            this.tipo = tipo;
        } else {
            throw new IllegalArgumentException("Tipo Inválido!");
        }
    }

    // GETTERS

    public String getTipo() {
        return tipo;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return super.toString() + "\nTipo: " + tipo;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Motociclo) {
            Motociclo m = (Motociclo) obj;
            return super.equals(m) && tipo.equals(m.getTipo());
        }
        return false;
    }
}
