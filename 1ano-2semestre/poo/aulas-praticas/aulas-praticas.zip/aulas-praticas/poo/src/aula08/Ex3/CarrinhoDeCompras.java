package aula08.Ex3;

import java.util.*;

public class CarrinhoDeCompras implements Compra {

    private Map<Produto, Integer> produtos = new HashMap<>();

    // SETTERS

    @Override
    public void adicionarProduto(Produto produto, int quantidade) {
        produtos.put(produto, quantidade);
    }

    // MÉTODOS
    
    @Override
    public void listarProdutos() {
        System.out.println("Produtos no carrinho:");
        for (Map.Entry<Produto, Integer> entry : produtos.entrySet()) {
            Produto produto = entry.getKey();
            int quantidade = entry.getValue();
            System.out.printf("- %s (%d unidades) - %.2f\n", produto.getNome(), quantidade, produto.getPreco());
        }
    }

    @Override
    public double calcularTotal() {
        double total = 0;
        for (Map.Entry<Produto, Integer> entry : produtos.entrySet()) {
            Produto produto = entry.getKey();
            int quantidade = entry.getValue();
            total += produto.getPreco() * quantidade;
        }
        return total;
    }
}