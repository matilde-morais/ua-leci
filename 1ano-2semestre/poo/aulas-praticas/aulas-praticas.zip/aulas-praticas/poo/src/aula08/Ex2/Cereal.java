package aula08.Ex2;

import java.util.*;

public class Cereal extends AlimentoBasico {

    // CONSTRUTOR

    public Cereal(String nome, double proteinas, double calorias, double peso) {
        super(nome, proteinas, calorias, peso);
    }

    // MÉTODOS

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        return true;
    }

}
