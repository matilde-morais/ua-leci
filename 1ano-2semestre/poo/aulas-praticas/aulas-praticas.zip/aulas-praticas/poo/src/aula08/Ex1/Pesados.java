package aula08.Ex1;

public class Pesados extends Veiculo {
    
    // ATRIBUTOS

    protected int numQuadro;
    protected int peso;

    // CONSTRUTORES
    
    public Pesados(String matricula, String marca, String modelo, int potenciaCV, int ultimoTrajeto, int distanciaTotal, int numQuadro, int peso) {
        super(matricula, marca, modelo, potenciaCV, ultimoTrajeto, distanciaTotal);

        // VALIDAÇÃO

        if (numQuadro > 0 && peso > 0) {
            this.numQuadro = numQuadro;
            this.peso = peso;
        } else {
            throw new IllegalArgumentException("Características Inválidas!");
        }
    }

    // SETTERS

    public void setNumQuadro(int numQuadro) {
        if (numQuadro > 0) {
            this.numQuadro = numQuadro;
        } else {
            throw new IllegalArgumentException("Número de Quadro Inválido!");
        }
    }

    public void setPeso(int peso) {
        if (peso > 0) {
            this.peso = peso;
        } else {
            throw new IllegalArgumentException("Peso Inválido!");
        }
    }

    // GETTERS

    public int getNumQuadro() {
        return numQuadro;
    }

    public int getPeso() {
        return peso;
    }

    // MÉTODOS

    @Override
    public String toString() {
        return super.toString() + "\n Número de Quadro: " + numQuadro + "\n Peso: " + peso;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Pesados) {
            Pesados p = (Pesados) obj;
            return super.equals(p) && numQuadro == p.getNumQuadro() && peso == p.getPeso();
        }
        return false;
    }
}