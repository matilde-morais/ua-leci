package aula08.Ex2;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Prato {

    // ATRIBUTOS

    private String nome;
    private List<Alimento> composicao;

    // CONSTRUTOR

    public Prato(String nome) {

        // VALIDAÇÃO

        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do Prato Inválido!");
        }
        this.nome = nome;
        this.composicao = new ArrayList<>();
    }

    // SETTERS

    public void addIngrediente(Alimento alimento) {
        composicao.add(alimento);
    }

    // GETTERS

    public double getPesoTotal() {
        double pesoTotal = 0.0;
        for (Alimento alimento : composicao) {
            pesoTotal += alimento.getPeso();
        }
        return pesoTotal;
    }

    public double getTotalCalorias() {
        double caloriasTotal = 0.0;
        for (Alimento alimento : composicao) {
            caloriasTotal += alimento.getCalorias();
        }
        return caloriasTotal;
    }

    public double getTotalProteinas() {
        double proteinasTotal = 0.0;
        for (Alimento alimento : composicao) {
            proteinasTotal += alimento.getProteinas();
        }
        return proteinasTotal;
    }

    // MÉTODOS

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Prato '").append(nome).append("', composto por ").append(composicao.size()).append(" ingredientes\n");
        for (int i = 0; i < composicao.size(); i++) {
            sb.append("Ingrediente ").append(i + 1).append(": ").append(composicao.get(i)).append("\n");
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, composicao);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Prato other = (Prato) obj;
        return Objects.equals(nome, other.nome) && Objects.equals(composicao, other.composicao);
    }

}
