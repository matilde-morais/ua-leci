package aula05;

import java.util.Scanner;
import aula05.DateYMD;

public class Ex1 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        DateYMD date = null;

        int option;

        // Menu
        do {
            System.out.println("Date operations: \n 1 - create new date \n 2 - show current date \n 3 - increment date \n 4 - decrement date \n 0 - exit \n");

            option = scanner.nextInt();

            switch(option) {
                case 1:
                    System.out.println("Insira o dia:");
                    int day = scanner.nextInt();
                    System.out.println("Insira o mês:");
                    int month = scanner.nextInt();
                    System.out.println("Insira o ano:");
                    int year = scanner.nextInt();

                    try {
                        date = new DateYMD(day, month, year);
                        System.out.println("Date created successfully!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid date. Please try again.");
                    }
                    break;
                case 2:
                    if (date != null) {
                        System.out.println(date.toString());
                    } else {
                        System.out.println("No date created yet.");
                    }
                    break;
                case 3:
                    if (date != null) {
                        date.increment();
                        System.out.println("Date incremented. New date: " + date);
                    } else {
                        System.out.println("No date created yet.");
                    }
                    break;
                case 4:
                    if (date != null) {
                        date.decrement();
                        System.out.println("Date decremented. New date: " + date);
                    } else {
                        System.out.println("No date created yet.");
                    }
                    break;
                case 0:
                    System.out.println("A sair...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        } while (option != 0);

        scanner.close();
    }
}