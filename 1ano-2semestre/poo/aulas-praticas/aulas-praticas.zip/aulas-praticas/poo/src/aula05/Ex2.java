package aula05;

import aula05.Calendar;
import java.util.Scanner;

public class Ex2 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Calendar calendar = null;

        int option;

        do {

            System.out.println("Calendar operations: \n 1 - create new calendar \n 2 - print calendar month \n 3 - print calendar \n 0 - exit \n");

            option = scanner.nextInt();

            switch(option) {
                case 1:
                    System.out.println("Insira o ano:");
                    int year = scanner.nextInt();
                    System.out.println("Insira o primeiro dia da semana (1 - Segunda, ..., 7 - Domingo):");
                    int firstWeekDay = scanner.nextInt();

                    try {
                        calendar = new Calendar(year, firstWeekDay);
                        System.out.println("Calendar created successfully.");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid input. Please try again.");
                    }
                    break;
                case 2:
                    if (calendar != null) {
                        System.out.println("Insira o mês:");
                        int month = scanner.nextInt();
                        System.out.println(calendar.printMonth(month));
                    } else {
                        System.out.println("No calendar created yet.");
                    }
                    break;
                case 3:
                    if (calendar != null) {
                        System.out.println(calendar.printCalendar());
                    } else {
                        System.out.println("No calendar created yet.");
                    }
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 0);

        scanner.close();
    }

}