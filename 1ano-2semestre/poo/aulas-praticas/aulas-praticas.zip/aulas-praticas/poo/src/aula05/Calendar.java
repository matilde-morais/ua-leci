package aula05;

import aula05.DateYMD;

public class Calendar {

    private int year;
    private String[][] events;
    private int firstWeekDay;

    public Calendar(int year, int firstWeekDay) {
        this.year = year;
        this.firstWeekDay = firstWeekDay;
        this.events = new String[12][];
        for (int i = 0; i < 12; i++) { // create a 2D array with the number of days in each month
            this.events[i] = new String[DateYMD.monthDays(i + 1, year)];
        }
    }

    public int year() {
        return year;
    }

    public int firstWeekDay() {
        return firstWeekDay;
    }

    public int firstWeekdayOfMonth(int month) {
        int days = 0;
        for (int i = 0; i < month - 1; i++) {
            days += DateYMD.monthDays(i + 1, year);
        }
        return (days + firstWeekDay) % 7;
    }

    public void addEvent(DateYMD date, String event) {
        events[date.getMonth() - 1][date.getDay() - 1] = event;
    }

    public void removeEvent(DateYMD date) {
        events[date.getMonth() - 1][date.getDay() - 1] = null;
    }

    public String printMonth(int month) {
        StringBuilder sb = new StringBuilder(); // StringBuilder permite criar strings mutáveis
        sb.append(monthName(month)).append(" ").append(year).append("\n");
        sb.append("Su Mo Tu We Th Fr Sa\n");
        int firstWeekday = firstWeekdayOfMonth(month);
        for (int i = 0; i < firstWeekday; i++) {
            sb.append("   ");
        }
        for (int day = 1; day <= DateYMD.monthDays(month, year); day++) {
            if (events[month - 1][day - 1] != null) {
                sb.append("*");
            } else {
                sb.append(" ");
            }
            sb.append(String.format("%2d", day));
            if ((firstWeekday + day) % 7 == 0) {
                sb.append("\n");
            } else {
                sb.append(" ");
            }
        }
        sb.append("\n");
        return sb.toString();
    }

    public String printCalendar() {
        StringBuilder sb = new StringBuilder();
        for (int month = 1; month <= 12; month++) {
            sb.append(printMonth(month)).append("\n");
        }
        return sb.toString();
    }

    private String monthName(int month) {
        switch (month) {
            case 1: return "January";
            case 2: return "February";
            case 3: return "March";
            case 4: return "April";
            case 5: return "May";
            case 6: return "June";
            case 7: return "July";
            case 8: return "August";
            case 9: return "September";
            case 10: return "October";
            case 11: return "November";
            case 12: return "December";
            default: return "";
        }
    }
}
