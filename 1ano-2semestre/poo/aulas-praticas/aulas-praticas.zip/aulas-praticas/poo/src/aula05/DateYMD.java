package aula05;

public class DateYMD {

    private int day;
    private int month;
    private int year;

    public DateYMD(int day, int month, int year) {
        if (valid(day, month, year)) {
            this.day = day;
            this.month = month;
            this.year = year;
        } else {
            throw new IllegalArgumentException("Data Inválida!");
        }
    }

    public void setDate(int day, int month, int year) {
        if (valid(day, month, year)) {
            this.day = day;
            this.month = month;
            this.year = year;
        } else {
            throw new IllegalArgumentException("Data Inválida!");
        }
    }

    public int getDay() {
        return day;  
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }
    
    public static boolean validMonth(int month) {
        return month >= 1 && month <= 12;
    }

    public static int monthDays(int month, int year) {
        if (validMonth(month)) {
            if (month == 2) {
                if (leapYear(year)) {
                    return 29;
                } else {
                    return 28;
                }
            } else if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                return 31;
            } else {
                return 30;
            }
        } else {
            throw new IllegalArgumentException("Mês inválido!");
        }
    }

    public static boolean leapYear(int year) {
        return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
    }

    public static boolean valid(int day, int month, int year) {
        if (year < 0) {
            return false;
        } else if  (month <1 || month > 12) {
            return false;
        } else if (day < 1 || day > monthDays(month, year)) {
            return false;
        } else {
            return true;
        }
    }

    public void increment() {
        day++;
        if (day > monthDays(month, year)) {
            day = 1;
            month++;
            if (month > 12) {
                month = 1;
                year++;
            }
        }
    }

    public void decrement() {
        day--;
        if (day < 1) {
            month--;
            if (month < 1) {
                month = 12;
                year--;
            }
            day = monthDays(month, year);
        }
    }

    @Override
    public String toString() {
        return "Data: " + year + "-" + month + "-" + day;
    }

}
