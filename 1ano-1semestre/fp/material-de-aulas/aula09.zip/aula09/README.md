# Aula09: Searching, sorting, lambda expressions.

O conteúdo desta aula não é tratado na bibliografia do costume.
Sugere-se a leitura dos slides e dos exemplos criados nas aulas TP.

