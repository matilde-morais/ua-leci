# Este programa é a solução de um dos exercícios da aula.

largura = float(input('Largura? '))
altura = float(input('Altura? '))

area = largura * altura
perimetro = largura*2 + altura*2

print('Area:', area)
print('Perimetro:', perimetro)

